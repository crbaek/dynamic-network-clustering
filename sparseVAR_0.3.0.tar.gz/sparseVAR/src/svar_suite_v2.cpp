// svar_suite.cpp
// Integrated Rcpp/Armadillo back-end for sVAR / sVHAR / sPVAR
//   - shared soft-threshold (optional mask, optional diagonal toggle)
//   - VAR(p) design matrix, VHAR design, sPVAR season design
//   - generic weighted multi-response lasso/adaptive-lasso via FISTA
//
// Notes:
//   * Objective (0.5 scaling, no 1/n factor):
//       0.5 * tr( (Y - X B) S (Y - X B)^T ) + lambda * sum_{i,j} w_{ij} |B_{ij}|
//     where S = SigmaInv (k x k). If SigmaInv is 0x0, S = I_k.
//   * Unpenalized coefficients are represented by weights = 0 (or equivalently threshold = 0).
//
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

using namespace Rcpp;
using arma::mat;
using arma::vec;

/* ============================================================
 * Soft-threshold with optional mask
 *   - base_thr: same shape as X, elementwise thresholds
 *   - if M_ptr is provided: thresholds are multiplied elementwise by M (0 => no penalty)
 *   - if penalize_diag == false: diagonal entries are copied unchanged (requires square matrix)
 * ============================================================ */
static inline mat soft_threshold_core(const arma::mat& X,
                                      const arma::mat& base_thr,
                                      const mat* M_ptr = nullptr,
                                      const bool penalize_diag = true) {
  if (X.n_rows != base_thr.n_rows || X.n_cols != base_thr.n_cols) {
    stop("soft_threshold_core: X and base_thr must have identical shape.");
  }

  arma::mat thr_eff = base_thr;
  if (M_ptr != nullptr) {
    if (M_ptr->n_rows != X.n_rows || M_ptr->n_cols != X.n_cols) {
      stop("soft_threshold_core: M must have the same shape as X.");
    }
    thr_eff %= (*M_ptr);
  }

  arma::mat out = X;
  const bool is_square = (X.n_rows == X.n_cols);

  for (arma::uword i = 0; i < X.n_rows; ++i) {
    for (arma::uword j = 0; j < X.n_cols; ++j) {
      if (!penalize_diag && is_square && i == j) continue;
      const double thr = thr_eff(i, j);
      if (thr <= 0.0) continue;
      const double v = X(i, j);
      const double a = std::abs(v) - thr;
      out(i, j) = (a > 0.0) ? ((v >= 0.0 ? 1.0 : -1.0) * a) : 0.0;
    }
  }
  return out;
}

// [[Rcpp::export]]
arma::mat soft_threshold_cpp(const arma::mat& X,
                       const arma::mat& base_thr,
                       Rcpp::Nullable<Rcpp::NumericMatrix> M_opt = R_NilValue,
                       bool penalize_diag = true) {
  if (M_opt.isNotNull()) {
    NumericMatrix Mr(M_opt);
    mat M(Mr.begin(), Mr.nrow(), Mr.ncol(), false);
    return soft_threshold_core(X, base_thr, &M, penalize_diag);
  }
  return soft_threshold_core(X, base_thr, nullptr, penalize_diag);
}

/* ============================================================
 * Largest eigenvalue (power iteration) for symmetric PSD matrices
 * ============================================================ */
static inline double power_iter_eigmax(const arma::mat& A, int max_iter = 250, double tol = 1e-10) {
  const arma::uword n = A.n_cols;
  vec v(n, arma::fill::randu);
  double nv = arma::norm(v, 2);
  if (nv == 0.0) { v.ones(); nv = arma::norm(v, 2); }
  v /= nv;

  double lambda_old = 0.0;
  for (int it = 0; it < max_iter; ++it) {
    vec w = A * v;
    double nw = arma::norm(w, 2);
    if (nw == 0.0) break;
    v = w / nw;

    double lambda = arma::dot(v, A * v);
    if (std::abs(lambda - lambda_old) <= tol * std::max(1.0, std::abs(lambda_old))) {
      lambda_old = lambda;
      break;
    }
    lambda_old = lambda;
  }
  return std::max(0.0, arma::dot(v, A * v));
}

/* ============================================================
 * VAR simulator & design matrix
 * ============================================================ */

// Simulate VAR: A is k x (k*p); Sigma is k x k; returns Y (k x T)
// [[Rcpp::export]]
arma::mat VAR_sim_cpp(int T, arma::mat A, arma::mat Sigma, int burn = 500) {
  const int k = (int)A.n_rows;
  const int p = (int)(A.n_cols / (arma::uword)k);
  const int total = T + burn;

  if (A.n_cols != (arma::uword)(k * p)) stop("A must be k x (k*p).");
  if (Sigma.n_rows != (arma::uword)k || Sigma.n_cols != (arma::uword)k) stop("Sigma must be k x k.");

  arma::mat inno = arma::mvnrnd(vec(k, arma::fill::zeros), Sigma, total).t();
  arma::mat init = arma::mvnrnd(vec(k, arma::fill::zeros), Sigma, p).t();
  mat Y(total, k, arma::fill::zeros);

  for (int r = 0; r < total; ++r) {
    vec lagged(k * p, arma::fill::zeros);
    for (int j = 0; j < p; ++j) {
      lagged.subvec(j * k, (j + 1) * k - 1) = init.row(p - j - 1).t();
    }
    arma::rowvec y_row = (A * lagged).t() + inno.row(r);
    Y.row(r) = y_row;
    init.shed_row(0);
    init.insert_rows(p - 1, y_row);
  }
  return Y.rows(burn, total - 1).t(); // k x T
}

// Build VAR(p) design from X (T x k): returns X_design ((T-p) x (k*p)) and Y ((T-p) x k)
// [[Rcpp::export]]
Rcpp::List create_var_design_matrix_cpp(const arma::mat& X, int p) {
  const int n = (int)X.n_rows; // T
  const int k = (int)X.n_cols;
  if (n <= p) stop("Not enough rows for the given lag p.");

  mat X_design(n - p, k * p, arma::fill::zeros);
  for (int i = 0; i < p; ++i) {
    X_design.cols(i * k, (i + 1) * k - 1) = X.rows(p - i - 1, n - i - 2);
  }
  arma::mat Y = X.rows(p, n - 1);
  return List::create(_["X_design"] = X_design,
                      _["Y_resp"]   = Y);
}

/* ============================================================
 * VHAR design: from Y (q x TT) to X_design (n x 3q), Y_resp (n x q)
 * with user-supplied bandwidths bd (middle horizon) and bm (long horizon)
 * ============================================================ */
// [[Rcpp::export]]
Rcpp::List vhar_design_cpp(const arma::mat& Y, int bd = 5, int bm = 22) {
  if (bd < 1 || bm < 1) stop("bd and bm must be positive integers.");
  if (bd > bm) stop("Require bd <= bm for VHAR bandwidths.");

  const arma::uword q  = Y.n_rows;
  const arma::uword TT = Y.n_cols;
  if (TT <= static_cast<arma::uword>(bm)) stop("Need TT > bm for VHAR design.");

  const arma::uword n = TT - static_cast<arma::uword>(bm);
  mat X(n, 3 * q, arma::fill::zeros);  // [D | W | M]
  mat Yresp(n, q, arma::fill::zeros);

  for (arma::uword i = 0; i < n; ++i) {
    const arma::uword t = static_cast<arma::uword>(bm) + i; // 0-based time index for response

    // response
    Yresp.row(i) = Y.col(t).t();

    // daily lag
    X.cols(0, q - 1).row(i) = Y.col(t - 1).t();

    // middle-horizon mean of last bd days
    for (arma::uword j = 0; j < q; ++j) {
      double s = 0.0;
      for (int h = 1; h <= bd; ++h) s += Y(j, t - static_cast<arma::uword>(h));
      X(i, q + j) = s / static_cast<double>(bd);
    }

    // long-horizon mean of last bm days
    for (arma::uword j = 0; j < q; ++j) {
      double s = 0.0;
      for (int h = 1; h <= bm; ++h) s += Y(j, t - static_cast<arma::uword>(h));
      X(i, 2 * q + j) = s / static_cast<double>(bm);
    }
  }

  return List::create(_["X_design"] = X, _["Y_resp"] = Yresp,
                      _["bd"] = bd, _["bm"] = bm);
}

/* ============================================================
 * Season-specific design for PVAR(1)
 *   Yt : q x TT
 *   s  : season period
 *   season : 1..s
 * Returns:
 *   X : n x q (lagged Y_{t-1} rows)
 *   Y : n x q (current Y_t rows)
 *   id: 1-based time indices t used
 * ============================================================ */
// [[Rcpp::export]]
Rcpp::List spvar_design_season_cpp(const arma::mat& Yt, int s, int season) {
  if (season < 1 || season > s) stop("season must be in 1..s.");
  const int q  = (int)Yt.n_rows;
  const int TT = (int)Yt.n_cols;
  if (TT <= 2) stop("Need TT > 2.");

  std::vector<int> ids;
  ids.reserve((TT + s - 1) / s);
  for (int t = season; t <= TT; t += s) {
    if (t > 1) ids.push_back(t);
  }
  const int n = (int)ids.size();
  if (n <= 1) stop("Not enough observations for this season.");

  mat X(n, q, arma::fill::zeros);
  mat Y(n, q, arma::fill::zeros);

  for (int r = 0; r < n; ++r) {
    const int t = ids[r];      // 1-based
    const int col = t - 1;     // 0-based
    const int lagcol = t - 2;
    Y.row(r) = Yt.col(col).t();
    X.row(r) = Yt.col(lagcol).t();
  }

  IntegerVector id_out(n);
  for (int r = 0; r < n; ++r) id_out[r] = ids[r];

  return List::create(_["X"] = X, _["Y"] = Y, _["id"] = id_out);
}

/* ============================================================
 * Generic weighted multi-response lasso/adaptive-lasso via FISTA
 *
 * Solve:
 *   minimize_B  0.5 * tr( (Y - X B) S (Y - X B)^T )
 *               + lambda * sum_{i,j} weights_{i,j} |B_{i,j}|
 *
 * Inputs:
 *   X : n x d
 *   Y : n x k
 *   weights : d x k (>=0; 0 => unpenalized)
 *   SigmaInv : k x k; pass 0x0 for identity
 *   step_size : if <= 0, set to 1/L where L = ||XtX||_2 * ||S||_2 with XtX=(X'X)
 *
 * VHAR convenience:
 *   If penalize_vhar_selflags == false and d == 3*k, then (j,j), (k+j,j), (2k+j,j)
 *   are treated as unpenalized regardless of weights.
 * ============================================================ */
// [[Rcpp::export]]
arma::mat fista_lasso_multi_cpp(
    const arma::mat& X,
    const arma::mat& Y,
    const arma::mat& weights,
    const double lambda,
    const arma::mat& SigmaInv,
    const int max_iter = 1000,
    const double tol = 1e-6,
    double step_size = -1.0,
    const bool penalize_vhar_selflags = true
) {
  const arma::uword n = X.n_rows;
  const arma::uword d = X.n_cols;
  const arma::uword k = Y.n_cols;

  if (Y.n_rows != n) stop("X and Y must have the same number of rows.");
  if (weights.n_rows != d || weights.n_cols != k) stop("weights must be d x k.");
  if (lambda < 0.0) stop("lambda must be nonnegative.");

  mat S;
  if (SigmaInv.n_rows == 0 || SigmaInv.n_cols == 0) {
    S = arma::eye(k, k);
  } else {
    if (SigmaInv.n_rows != k || SigmaInv.n_cols != k) stop("SigmaInv must be k x k or 0 x 0.");
    S = 0.5 * (SigmaInv + SigmaInv.t()); // symmetrize for numerical safety
  }
  // 0.5 scaling without 1/n: use XtX = X'X and XtY = X'Y
  arma::mat XtX = (X.t() * X);  // d x d
  arma::mat XtY = (X.t() * Y);  // d x k
  // Effective weights (handle VHAR self-lags as unpenalized)
  arma::mat W = weights;
  if (!penalize_vhar_selflags && d == 3 * k) {
    for (arma::uword j = 0; j < k; ++j) {
      W(j, j)         = 0.0;
      W(k + j, j)     = 0.0;
      W(2 * k + j, j) = 0.0;
    }
  }

  // Step size
  if (step_size <= 0.0) {
    const double Lx = power_iter_eigmax(XtX);
    const double Ls = power_iter_eigmax(S);
    const double L  = std::max(1e-12, Lx * Ls);
    step_size = 1.0 / L;
  }

  const arma::mat thr = (lambda * step_size) * W;

  mat B(d, k, arma::fill::zeros);
  mat B_prev(d, k, arma::fill::zeros);
  arma::mat Z = B;
  double t = 1.0;

  for (int it = 0; it < max_iter; ++it) {
    B_prev = B;

    // grad = (XtX * Z - XtY) * S
    arma::mat G = (XtX * Z - XtY) * S;

    arma::mat U = Z - step_size * G;
    arma::mat Bnew = soft_threshold_core(U, thr, nullptr, true);

    const double tnew = 0.5 * (1.0 + std::sqrt(1.0 + 4.0 * t * t));
    Z = Bnew + ((t - 1.0) / tnew) * (Bnew - B);

    const double denom = std::max(1.0, arma::norm(B, "fro"));
    const double relchg = arma::norm(Bnew - B, "fro") / denom;

    B = Bnew;
    t = tnew;

    if (relchg < tol) break;
  }

  return B;
}

/* ============================================================
 * Backward-compatible alias for sPVAR code (same semantics)
 * ============================================================ */
// [[Rcpp::export]]
arma::mat fista_spvar_multi_cpp(const arma::mat& X,
                          const arma::mat& Y,
                          const arma::mat& weights,
                          double lambda,
                          const arma::mat& SigmaInv,
                          int max_iter = 4000,
                          double tol = 1e-7,
                          double step_size = -1.0) {
  return fista_lasso_multi_cpp(X, Y, weights, lambda, SigmaInv, max_iter, tol, step_size, true);
}
