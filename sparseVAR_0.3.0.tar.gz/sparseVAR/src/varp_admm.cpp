#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

namespace {

inline arma::mat make_sigma_cpp(const arma::mat& SigmaInv, arma::uword k) {
  if (SigmaInv.n_rows == 0 || SigmaInv.n_cols == 0) {
    return arma::eye<arma::mat>(k, k);
  }
  if (SigmaInv.n_rows != k || SigmaInv.n_cols != k) {
    stop("SigmaInv must be k x k or 0 x 0.");
  }
  return 0.5 * (SigmaInv + SigmaInv.t());
}

inline arma::vec soft_threshold_vec_cpp(const arma::vec& x, const arma::vec& thr) {
  arma::vec out = arma::sign(x) % arma::clamp(arma::abs(x) - thr, 0.0, datum::inf);
  return out;
}

} // anonymous namespace

/*
 * Weighted multi-response ADMM for VAR(p)-type matrix regression.
 *
 * Solves
 *   min_B  0.5 * tr((Y - X B) S (Y - X B)^T)
 *          + lambda * sum_{i,j} weights_{ij} |B_{ij}|,
 * where B is d x k, X is n x d, Y is n x k, and S = SigmaInv or I.
 */
// [[Rcpp::export]]
Rcpp::List admm_varp_multi_cpp(const arma::mat& X,
                               const arma::mat& Y,
                               const arma::mat& weights,
                               const double lambda,
                               const arma::mat& SigmaInv,
                               const int max_iter = 1000,
                               const double rho = 1.0,
                               const double tol = 1e-6) {
  const arma::uword n = X.n_rows;
  const arma::uword d = X.n_cols;
  const arma::uword k = Y.n_cols;
  const arma::uword q = d * k;

  if (Y.n_rows != n) stop("X and Y must have the same number of rows.");
  if (weights.n_rows != d || weights.n_cols != k) stop("weights must be d x k.");
  if (lambda < 0.0) stop("lambda must be nonnegative.");
  if (rho <= 0.0) stop("rho must be positive.");

  const arma::mat S = make_sigma_cpp(SigmaInv, k);
  const arma::mat XtX = X.t() * X;      // d x d
  const arma::mat XtYS = X.t() * Y * S; // d x k

  arma::mat H = arma::kron(S.t(), XtX); // (dk) x (dk)
  H.diag() += rho;
  const arma::vec rhs0 = arma::vectorise(XtYS);

  const arma::vec thr = (lambda / rho) * arma::vectorise(weights);

  arma::vec beta(q, fill::zeros), z(q, fill::zeros), u(q, fill::zeros);
  bool converged = false;
  int n_iter = max_iter;

  for (int iter = 0; iter < max_iter; ++iter) {
    const arma::vec rhs = rhs0 + rho * (z - u);

    bool ok = arma::solve(beta, H, rhs, arma::solve_opts::likely_sympd);
    if (!ok) {
      beta = arma::solve(H, rhs);
    }

    const arma::vec z_new = soft_threshold_vec_cpp(beta + u, thr);
    const arma::vec u_new = u + beta - z_new;

    const double r_norm = arma::norm(beta - z_new, 2);
    const double s_norm = rho * arma::norm(z_new - z, 2);
    const double eps_pri  = std::sqrt(static_cast<double>(q)) * tol +
      tol * std::max(arma::norm(beta, 2), arma::norm(z_new, 2));
    const double eps_dual = std::sqrt(static_cast<double>(q)) * tol +
      tol * rho * arma::norm(u_new, 2);

    z = z_new;
    u = u_new;

    if (r_norm <= eps_pri && s_norm <= eps_dual) {
      converged = true;
      n_iter = iter + 1;
      break;
    }
  }

  arma::mat B(beta.memptr(), d, k, false, true);
  arma::mat Bout = B;
  return Rcpp::List::create(
    _["B"] = Bout,
    _["converged"] = converged,
    _["n_iter"] = n_iter,
    _["rho"] = rho
  );
}
