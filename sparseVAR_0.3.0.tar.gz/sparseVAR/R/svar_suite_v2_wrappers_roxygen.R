# svar_suite.R
# Integrated R wrappers for sparse VAR / VHAR / PVAR
#   - algorithms: glmnet (adaptive lasso) and Rcpp-FISTA
#   - consistent outputs: Phi_hat_{ols,lasso,Alasso}, lambda_{lasso,adalasso}
#   - optional debias/relaxed via active-set refit
#
# Requires:
#   - glmnet (for glmnet-based estimators)
#   - Matrix (for sparse kronecker designs)
#   - Rcpp back-end (compile src/svar_suite.cpp in the package)


.block_foldid <- function(n, nf) {
  nf <- as.integer(nf)
  if (nf < 2L) stop("nf must be >= 2.")
  rep(seq_len(nf), each = floor(n / nf) + 1L)[1L:n]
}

.sig_invsqrt <- function(Sigma, whiten = c("full", "diag")) {
  whiten <- match.arg(whiten)
  if (whiten == "diag") {
    d <- diag(Sigma)
    return(diag(1 / sqrt(pmax(d, 1e-12)), nrow(Sigma), ncol(Sigma)))
  }
  sv <- svd(Sigma)
  sv$u %*% diag(1 / sqrt(pmax(sv$d, 1e-12))) %*% t(sv$u)
}

# Diagonal coefficient indices in vec(Phi) (column-major) for VAR(p):
#   Phi is k x (k*p) and vec(Phi) stacks columns.
.diag_exclude_idx_varp <- function(k, p) {
  idx <- integer(k * p)
  pos <- 1L
  for (ell in seq_len(p)) {
    base <- (ell - 1L) * k * k
    for (j in seq_len(k)) {
      idx[pos] <- base + (j - 1L) * k + j
      pos <- pos + 1L
    }
  }
  idx
}

# Diagonal exclusion indices in vec(Phi) for VHAR (q x 3q): D,W,M blocks
.diag_exclude_idx_vhar <- function(q) {
  tmp <- matrix(seq_len(q * q), q, nrow = q, byrow = FALSE)
  dtmp <- diag(tmp)
  c(dtmp, dtmp + q * q, dtmp + 2 * q * q)
}

# For FISTA back-end (B is d x k): create base weight matrix (d x k)
.make_varp_weights <- function(k, p, diagTF = TRUE) {
  d <- k * p
  W <- matrix(1, d, k)
  if (diagTF) {
    for (ell in seq_len(p)) {
      for (j in seq_len(k)) {
        ridx <- (ell - 1L) * k + j
        W[ridx, j] <- 0
      }
    }
  }
  W
}

# KKT lambda grid for (1/2) objective (no 1/n factor):
#   lambda_max = max_{w>0} |(X^T Y * SigmaInv)_{ij}| / w_{ij}
.kkt_lambda_grid_fista <- function(X, Y, W, SigmaInv = NULL,
                                  nlambda = 100, lambda_min_ratio = NULL) {
  X <- as.matrix(X); Y <- as.matrix(Y); W <- as.matrix(W)
  n <- nrow(X)
  if (is.null(lambda_min_ratio)) lambda_min_ratio <- if (n > ncol(X)) 1e-4 else 1e-2

  G <- crossprod(X, Y)
  if (!is.null(SigmaInv)) G <- G %*% SigmaInv

  den <- W
  den[den == 0] <- Inf
  lam_max <- max(abs(G) / den, na.rm = TRUE)
  if (!is.finite(lam_max) || lam_max <= 0) return(rep(0, nlambda))
  lam_min <- lam_max * lambda_min_ratio
  exp(seq(log(lam_max), log(lam_min), length.out = nlambda))
}

# Block-CV selection (no shuffle) for multiresponse FISTA
.cv_select_lambda_fista <- function(X, Y, W, lambdas, SigmaInv,
                                   n_folds = 10,
                                   max_iter = 1000, tol = 1e-6,
                                   penalize_vhar_selflags = TRUE) {
  X <- as.matrix(X); Y <- as.matrix(Y); W <- as.matrix(W)
  n <- nrow(X)
  folds <- rep(seq_len(n_folds), each = floor(n / n_folds) + 1L)[1L:n]
  SigArg <- if (is.null(SigmaInv)) matrix(0, 0, 0) else as.matrix(SigmaInv)

  cv <- numeric(length(lambdas))
  for (ii in seq_along(lambdas)) {
    lam <- lambdas[ii]
    sse <- 0
    for (ff in seq_len(n_folds)) {
      tr <- which(folds != ff)
      va <- which(folds == ff)

      Bhat <- fista_lasso_multi_cpp(
        X = X[tr, , drop = FALSE],
        Y = Y[tr, , drop = FALSE],
        weights = W,
        lambda = lam,
        SigmaInv = SigArg,
        max_iter = max_iter,
        tol = tol,
        penalize_vhar_selflags = penalize_vhar_selflags
      )

      Rv <- Y[va, , drop = FALSE] - X[va, , drop = FALSE] %*% Bhat
      if (is.null(SigmaInv)) {
        sse <- sse + sum(Rv^2)
      } else {
        sse <- sse + sum((Rv %*% SigmaInv) * Rv)
      }
    }
    cv[ii] <- sse
  }
  lambdas[which.min(cv)]
}

# ------------------------------------------------------------
# Adaptive lasso via glmnet with block-CV
#   Stage-1: lasso
#   Stage-2: adaptive lasso with weights 1/|beta_lasso|
# ------------------------------------------------------------
#' Adaptive lasso via glmnet with blocked cross-validation
#'
#' Internal utility that fits (i) a lasso model and (ii) an adaptive lasso model
#' using \pkg{glmnet}. Cross-validation folds are constructed in contiguous blocks
#' to respect time ordering.
#'
#' The adaptive weights are computed as \eqn{w_j = 1 / \max(|\hat\beta^{\text{lasso}}_j|, \text{eps})},
#' capped at \code{cap}. Predictors in \code{exclude} are treated as unpenalized.
#'
#' @param X Numeric design matrix (observations in rows).
#' @param y Numeric response vector.
#' @param nf Number of (blocked) folds.
#' @param alpha Elastic-net mixing parameter (1 = lasso).
#' @param relaxTF Logical; use relaxed refit in \code{cv.glmnet} when supported.
#' @param exclude Integer indices of columns in \code{X} to exclude from penalization.
#' @param eps Small constant for adaptive weights.
#' @param cap Upper bound for adaptive weights.
#' @param standardize Logical; passed to glmnet.
#' @param lambda Optional lambda grid. If \code{NULL}, \code{cv.glmnet} chooses the grid.
#'
#' @return A list with lasso/adaptive-lasso fits and selected lambdas, including
#' \code{lasso}, \code{Alasso}, \code{lambda_lasso}, \code{lambda_adalasso},
#' and the underlying glmnet fit objects.
#'
#' @keywords internal
adalasso.glmnet <- function(X, y, nf = 10, alpha = 1,
                            relaxTF = TRUE,
                            exclude = NULL,
                            eps = 1e-8,
                            cap = 1e6,
                            standardize = TRUE,
                            lambda = NULL) {

  if (!requireNamespace("glmnet", quietly = TRUE)) stop("Package 'glmnet' is required.")
  y <- as.numeric(y)

  n <- length(y)
  foldid <- .block_foldid(n, nf)

  pf0 <- rep(1, ncol(X))
  if (!is.null(exclude)) pf0[exclude] <- 0

  # ----- Stage 1: lasso -----
  if (is.null(lambda)) {
    bb <- glmnet::cv.glmnet(
      x = X, y = y,
      intercept = FALSE,
      alpha = 1,
      foldid = foldid,
      keep = TRUE,
      standardize = standardize,
      penalty.factor = pf0
    )
    lambda_lasso <- bb$lambda.min
    cf <- glmnet::predict.glmnet(bb$glmnet.fit, type = "coefficients", s = lambda_lasso)
    cf <- as.numeric(cf[-1])
    fit_lasso <- bb
  } else {
    lam <- sort(unique(as.numeric(lambda)), decreasing = TRUE)
    bb <- glmnet::glmnet(
      x = X, y = y,
      intercept = FALSE,
      alpha = 1,
      lambda = lam,
      standardize = standardize,
      penalty.factor = pf0
    )
    lambda_lasso <- lam[length(lam)]
    cf <- glmnet::predict.glmnet(bb, type = "coefficients", s = lambda_lasso)
    cf <- as.numeric(cf[-1])
    fit_lasso <- bb
  }

  # ----- Stage 2: adaptive weights -----
  pf <- 1 / pmax(abs(cf), eps)
  pf <- pmin(pf, cap)
  if (!is.null(exclude)) pf[exclude] <- 0
  valid <- sum(pf != 0 & is.finite(pf))

  out <- list(
    fit_lasso = fit_lasso,
    lambda_lasso = lambda_lasso,
    lasso = cf,
    pf = pf
  )

  if (valid > 1L) {
    if (is.null(lambda)) {
      cc <- glmnet::cv.glmnet(
        x = X, y = y,
        intercept = FALSE,
        alpha = alpha,
        grouped = FALSE,
        foldid = foldid,
        penalty.factor = pf,
        keep = TRUE,
        standardize = standardize,
        relax = relaxTF
      )
      lambda_adalasso <- cc$lambda.min
      df <- glmnet::predict.glmnet(cc$glmnet.fit, type = "coefficients", s = lambda_adalasso)
      out$fit_adalasso <- cc
      out$lambda_adalasso <- lambda_adalasso
      out$Alasso <- as.numeric(df[-1])
    } else {
      lam <- sort(unique(as.numeric(lambda)), decreasing = TRUE)
      cc <- glmnet::glmnet(
        x = X, y = y,
        intercept = FALSE,
        alpha = alpha,
        lambda = lam,
        standardize = standardize,
        penalty.factor = pf
      )
      lambda_adalasso <- lam[length(lam)]
      df <- glmnet::predict.glmnet(cc, type = "coefficients", s = lambda_adalasso)
      out$fit_adalasso <- cc
      out$lambda_adalasso <- lambda_adalasso
      out$Alasso <- as.numeric(df[-1])
    }
  } else {
    out$fit_adalasso <- NULL
    out$lambda_adalasso <- NA_real_
    out$Alasso <- cf
  }

  out
}

# ============================================================
# sVAR (VAR(p)) : design + OLS + Sigma
# ============================================================

# Design matrix construction: VAR(p)
#   Input: Yt is k x TT
#   Output: list(X_design = (TT-p) x (k*p), Y_resp = (TT-p) x k)
#' Construct the VAR(p) regression design
#'
#' Builds the lagged design matrix for a VAR(p) model from a \eqn{k \times T}
#' time series matrix \code{Yt} (variables in rows, time in columns).
#' The returned design corresponds to the regression
#' \deqn{Y = X B + U,}
#' where \eqn{X} stacks \eqn{(y_{t-1}^\top,\dots,y_{t-p}^\top)} and
#' \eqn{Y} stacks \eqn{y_t^\top}.
#'
#' If the compiled routine \code{create_var_design_matrix_cpp} is available, it is used.
#'
#' @param Yt Numeric matrix of dimension \eqn{k \times T}.
#' @param p Integer lag order with \eqn{1 \le p < T}.
#'
#' @return A list with
#' \itemize{
#'   \item \code{X_design}: \eqn{(T-p) \times (k p)} design matrix,
#'   \item \code{Y_resp}: \eqn{(T-p) \times k} response matrix.
#' }
#'
#'
#' @seealso \code{\link{VAR_ols}}, \code{\link{sVAR_adalasso}}, \code{\link{sVAR_adalasso_fista}}
#' @keywords internal
var_design <- function(Yt, p) {
  if (!is.matrix(Yt)) Yt <- as.matrix(Yt)
  k  <- nrow(Yt)
  TT <- ncol(Yt)
  if (p < 1L || p >= TT) stop("p must satisfy 1 <= p < ncol(Yt).")

  # Prefer C++ if available: expects X = TT x k
  if (exists("create_var_design_matrix_cpp", mode = "function")) {
    des <- create_var_design_matrix_cpp(t(Yt), p)
    return(list(X_design = des$X_design, Y_resp = des$Y_resp))
  }

  # R fallback
  n <- TT - p
  Xd <- matrix(0.0, nrow = n, ncol = k * p)
  Y  <- t(Yt[, (p + 1L):TT, drop = FALSE])  # n x k
  for (t in seq_len(n)) {
    cols <- 1L
    for (ell in seq_len(p)) {
      Xd[t, cols:(cols + k - 1L)] <- Yt[, p + t - ell, drop = TRUE]
      cols <- cols + k
    }
  }
  list(X_design = Xd, Y_resp = Y)
}

#' OLS fit for VAR(p)
#'
#' Fits the VAR(p) coefficients by ordinary least squares. Optionally applies a
#' whitening matrix \code{hal} to \code{Yt} before constructing the design.
#'
#' @param Yt Numeric matrix \eqn{k \times T} (variables in rows).
#' @param p Integer lag order.
#' @param eps Ridge stabilization added to \eqn{X^\top X}.
#' @param hal Optional \eqn{k\times k} whitening matrix. If \code{NULL}, identity is used.
#'
#' @return A list with
#' \itemize{
#'   \item \code{Phi_hat}: estimated transition matrix \eqn{k \times (k p)},
#'   \item \code{X_design}, \code{Y_resp}: matrices used in the regression,
#'   \item \code{hal}: whitening matrix actually used.
#' }
#'
#' @examples
#' \dontrun{
#' fit <- VAR_ols(Yt, p = 1)
#' dim(fit$Phi_hat)
#' }
#' @seealso \code{\link{VAR_sigma}}, \code{\link{var_design}}
#' @export
VAR_ols <- function(Yt, p, eps = 1e-8, hal = NULL) {
  if (!is.matrix(Yt)) Yt <- as.matrix(Yt)
  k <- nrow(Yt)
  if (is.null(hal)) hal <- diag(k)

  des <- var_design(hal %*% Yt, p = p)
  Xd  <- des$X_design
  Y   <- des$Y_resp

  XtX <- crossprod(Xd) + eps * diag(1, ncol(Xd))
  XtY <- crossprod(Xd, Y)
  B_dk <- solve(XtX, XtY)  # d x k

  list(Phi_hat = t(B_dk), X_design = Xd, Y_resp = Y, hal = hal)
}

#' Residual covariance for a fitted VAR(p)
#'
#' Computes residuals and the residual covariance matrix for a supplied
#' VAR(p) coefficient matrix \code{Phi_hat}.
#'
#' @param Yt Numeric matrix \eqn{k \times T}.
#' @param p Integer lag order.
#' @param Phi_hat Coefficient matrix \eqn{k \times (k p)}.
#' @param hal Optional whitening matrix (applied to \code{Yt} before design construction).
#'
#' @return A list with
#' \itemize{
#'   \item \code{Resi}: residual matrix \eqn{k \times (T-p)},
#'   \item \code{Sigma_z}: residual covariance matrix \eqn{k \times k}.
#' }
#'
#' @seealso \code{\link{VAR_ols}}
#' @keywords internal
VAR_sigma <- function(Yt, p, Phi_hat, hal = NULL) {
  if (!is.matrix(Yt)) Yt <- as.matrix(Yt)
  k <- nrow(Yt)
  if (is.null(hal)) hal <- diag(k)

  des <- var_design(hal %*% Yt, p = p)
  Xd  <- des$X_design
  Y   <- des$Y_resp

  Res <- Y - Xd %*% t(Phi_hat)
  Sigma_z <- crossprod(Res) / nrow(Res)
  list(Resi = t(Res), Sigma_z = Sigma_z)
}

# Active-set refit (per-equation)
#' Active-set refit for sparse VAR(p) estimates
#'
#' Performs equation-by-equation refitting by OLS on the active set implied by
#' a sparse coefficient matrix \code{Phi_sparse}. This is used for debiasing and
#' relaxed estimation.
#'
#' @param X_design Design matrix \eqn{n \times d}.
#' @param Y_resp Response matrix \eqn{n \times k}.
#' @param Phi_sparse Sparse coefficient matrix \eqn{k \times d}; nonzeros define the active set.
#' @param eps Ridge stabilization added to \eqn{X^\top X}.
#'
#' @return A dense coefficient matrix \eqn{k \times d} containing the active-set refit.
#'
#' @seealso \code{\link{VAR_relaxed}}
#' @keywords internal
VAR_active_refit <- function(X_design, Y_resp, Phi_sparse, eps = 1e-8) {
  X_design <- as.matrix(X_design); Y_resp <- as.matrix(Y_resp)
  k <- ncol(Y_resp)
  d <- ncol(X_design)

  B_dk <- matrix(0.0, nrow = d, ncol = k)
  for (j in seq_len(k)) {
    ids <- which(Phi_sparse[j, ] != 0)
    if (length(ids) == 0L) next
    Xs <- X_design[, ids, drop = FALSE]
    XtX <- crossprod(Xs) + eps * diag(1, ncol(Xs))
    XtY <- crossprod(Xs, Y_resp[, j, drop = TRUE])
    B_dk[ids, j] <- as.vector(solve(XtX, XtY))
  }
  t(B_dk)  # k x d
}

#' Relaxed (debiasing) combination for VAR coefficients
#'
#' Forms the relaxed estimate
#' \deqn{\Phi_{\text{relaxed}} = \gamma \Phi_{\text{sparse}} + (1-\gamma)\Phi_{\text{active}},}
#' where \code{Phi_active} is typically the active-set refit of \code{Phi_sparse}.
#'
#' @param Phi_sparse Sparse estimate (e.g., lasso or adaptive lasso).
#' @param Phi_active Active-set refit coefficients.
#' @param gam Mixing weight \eqn{\gamma \in [0,1]}.
#'
#' @return A coefficient matrix with the same dimension as \code{Phi_sparse}.
#'
#' @export
VAR_relaxed <- function(Yt, Phi_hat, p, gam = 0.5) {
  if (gam < 0 || gam > 1) stop("gam must be in [0,1].")
  des <- var_design(Yt, p); ff= list();
  ff$Phi_active <- VAR_active_refit(des$X_design, des$Y_resp, Phi_hat)
  ff$Phi_relaxed = gam * Phi_hat + (1 - gam) * ff$Phi_active;
  return(ff)
}

# ============================================================
# sVAR via glmnet adaptive lasso (vectorized, X ⊗ I_k)
# ============================================================
#' Sparse VAR(p) via lasso and adaptive lasso (glmnet)
#'
#' Estimates a sparse VAR(p) transition matrix by vectorizing the multi-equation
#' regression and applying lasso followed by adaptive lasso using \pkg{glmnet}.
#' Optionally updates a whitening matrix based on the residual covariance.
#'
#' @param Yt Numeric matrix \eqn{k \times T}.
#' @param p Lag order.
#' @param fold Number of (blocked) CV folds for lambda selection.
#' @param diagTF Logical; if \code{TRUE}, VAR self-lag coefficients are treated as unpenalized.
#' @param updateSigma Logical; if \code{TRUE}, update the whitening matrix from residuals.
#' @param iterateTF Logical; if \code{TRUE}, iterate (fit -> updateSigma) until convergence/budget.
#' @param whiten Whitening type used when \code{updateSigma=TRUE}: \code{"diag"} or \code{"full"}.
#' @param relaxTF Logical; enable relaxed refit in glmnet CV (when supported).
#' @param debiasTF Logical; if \code{TRUE}, compute active-set refit and relaxed estimate.
#' @param gam Mixing weight for relaxed estimate.
#' @param lambda Optional lambda grid passed to glmnet. If \code{NULL}, glmnet chooses a grid.
#' @param eps_ols Ridge stabilization for OLS steps.
#' @param standardize Passed to glmnet.
#'
#' @return A list containing (at least)
#' \itemize{
#'   \item \code{Phi_hat_lasso}, \code{Phi_hat_Alasso}, \code{Phi_hat_ols},
#'   \item \code{lambda_lasso}, \code{lambda_adalasso}, and glmnet fit objects,
#'   \item \code{Sigma_z}, \code{hal}, and metadata (\code{p}, \code{k}, \code{fold}, \code{diagTF}),
#'   \item if \code{debiasTF=TRUE}: \code{Phi_hat_active}, \code{Phi_hat_relaxed}, \code{gam}.
#' }
#'
#' @examples
#' \dontrun{
#' fit <- sVAR_adalasso(Yt, p = 1, fold = 5)
#' }
#'
#' @seealso \code{\link{sVAR_adalasso_fista}}
#' @export
sVAR_adalasso <- function(Yt, p = 1, fold = 10,
                          diagTF = TRUE,
                          updateSigma = TRUE,
                          iterateTF = FALSE,
                          whiten = c("diag", "full"),
                          relaxTF = TRUE,
                          debiasTF = FALSE,
                          gam = 0.5,
                          lambda = NULL,
                          eps_ols = 1e-8,
                          standardize = TRUE) {

  if (!is.matrix(Yt)) Yt <- as.matrix(Yt)
  k  <- nrow(Yt)
  TT <- ncol(Yt)
  if (p < 1L || p >= TT) stop("p must satisfy 1 <= p < ncol(Yt).")

  whiten <- match.arg(whiten)

  # center by row mean (no intercept)
  Yt <- Yt - rowMeans(Yt)

  # diagonal non-penalization indices in vec(Phi)
  exclude <- if (diagTF) .diag_exclude_idx_varp(k, p) else NULL

  hal <- diag(k)
  Phi_prev <- NULL
  Sig <- NULL

  max_iter <- if (isTRUE(updateSigma)) { if (isTRUE(iterateTF)) 3L else 2L } else 1L

  for (it in seq_len(max_iter)) {
    des <- var_design(hal %*% Yt, p = p)
    Xd  <- des$X_design
    Y   <- des$Y_resp

    if (!requireNamespace("Matrix", quietly = TRUE)) stop("Package 'Matrix' is required.")
    X_big <- Matrix::kronecker(Matrix::Matrix(Xd, sparse = FALSE), Matrix::Diagonal(k))
    y_vec <- as.numeric(t(Y))

    pp <- adalasso.glmnet(
      X = X_big, y = y_vec,
      nf = fold, alpha = 1,
      relaxTF = relaxTF,
      exclude = exclude,
      standardize = standardize,
      lambda = lambda
    )

    Phi_lasso  <- matrix(pp$lasso,  nrow = k)
    Phi_Alasso <- matrix(pp$Alasso, nrow = k)

    if (isTRUE(updateSigma)) {
      Sig <- VAR_sigma(Yt, p = p, Phi_hat = Phi_Alasso, hal = diag(k))$Sigma_z
      hal_new <- .sig_invsqrt(Sig, whiten = whiten)

      if (it < max_iter) {
        if (!is.null(Phi_prev)) {
          diff <- sum((Phi_Alasso - Phi_prev)^2)
          if (diff < 1e-2) { hal <- hal_new; break }
        }
        Phi_prev <- Phi_Alasso
        hal <- hal_new
      }
    }
  }

  ols <- VAR_ols(Yt, p = p, eps = eps_ols, hal = hal)$Phi_hat

  out <- list(
    model = "sVAR", algo = "glmnet",
    Phi_hat_Alasso = Phi_Alasso,
    Phi_hat_lasso  = Phi_lasso,
    Phi_hat_ols    = ols,
    Sigma_z        = Sig,
    hal            = hal,
    p              = p,
    k              = k,
    fold           = fold,
    diagTF         = diagTF,
    lambda_lasso    = pp$lambda_lasso,
    lambda_adalasso = pp$lambda_adalasso,
    fit_lasso      = pp$fit_lasso,
    fit_adalasso   = pp$fit_adalasso
  )

  if (isTRUE(debiasTF)) {
    fa = VAR_relaxed(Yt, Phi_Alasso, p=p, gam = 0.5)
    out$Phi_hat_active  <- fa$Phi_active
    out$Phi_hat_relaxed <- fa$Phi_relaxed;
    out$gam <- gam
  }

  out
}

# ============================================================
# sVAR via FISTA (Rcpp): lasso -> adaptive lasso
#   Uses 0.5 scaling (no 1/n) consistent with the integrated FISTA solver.
# ============================================================
#' Sparse VAR(p) via lasso and adaptive lasso (FISTA back-end)
#'
#' Estimates lasso and adaptive-lasso VAR(p) coefficients using a compiled FISTA solver.
#' Supports unpenalizing diagonal self-lags via weight masking when \code{diagTF=TRUE}.
#'
#' @param Yt Numeric matrix \eqn{k \times T}.
#' @param p Lag order.
#' @param fold Number of (blocked) CV folds for lambda selection.
#' @param diagTF Logical; unpenalize VAR self-lags.
#' @param standardize Logical; column-scale design/response before optimization (no centering).
#' @param updateSigma Logical; if \code{TRUE}, include \code{SigmaInv} in the quadratic loss.
#' @param sigma_diag_only Logical; if \code{TRUE}, use only diagonal covariance for \code{SigmaInv}.
#' @param nlambda Size of lambda grid.
#' @param lambda_min_ratio Ratio of minimum lambda to maximum lambda.
#' @param max_iter Maximum FISTA iterations.
#' @param tol Convergence tolerance.
#' @param debiasTF Logical; if \code{TRUE}, compute active-set refit and relaxed estimate.
#' @param gam Mixing weight for relaxed estimate.
#' @param eps_w Stabilization constant for adaptive-lasso weights.
#'
#' @return A list containing sparse estimates and lambda selections, including
#' \code{Phi_hat_lasso}, \code{Phi_hat_Alasso}, \code{Phi_hat_ols},
#' selected lambdas and grids, optional \code{SigmaInv}, and (if requested) debias/relaxed outputs.
#'
#' @examples
#' \dontrun{
#' fit <- sVAR_adalasso_fista(Yt, p = 1, fold = 5)
#' }
#'
#' @seealso \code{\link{sVAR_adalasso}}, \code{\link{VAR_active_refit}}
#' @export
sVAR_adalasso_fista <- function(Yt, p = 1,
                                fold = 5,
                                diagTF = TRUE,
                                standardize = TRUE,
                                updateSigma = FALSE,
                                sigma_diag_only = TRUE,
                                nlambda = 100,
                                lambda_min_ratio = 1e-4,
                                max_iter = 1000,
                                tol = 1e-5,
                                debiasTF = FALSE,
                                gam = 0.5,
                                eps_w = 1e-8) {

  if (!is.matrix(Yt)) Yt <- as.matrix(Yt)
  k  <- nrow(Yt)
  TT <- ncol(Yt)
  if (p < 1L || p >= TT) stop("p must satisfy 1 <= p < ncol(Yt).")

  if (!exists("fista_lasso_multi_cpp", mode = "function")) {
    stop("fista_lasso_multi_cpp not found. Compile src/svar_suite.cpp (or sourceCpp) first.")
  }

  # center (no intercept)
  Yt <- Yt - rowMeans(Yt)

  des <- var_design(Yt, p = p)
  Xd <- as.matrix(des$X_design)  # n x d
  Y  <- as.matrix(des$Y_resp)    # n x k
  n  <- nrow(Xd)
  d  <- ncol(Xd)

  # optional standardization (column-wise)
  X_sd <- rep(1, d); Y_sd <- rep(1, k)
  Xs <- Xd; Ys <- Y
  if (isTRUE(standardize)) {
    X_sd <- apply(Xd, 2, sd); X_sd[X_sd == 0] <- 1
    Y_sd <- apply(Y,  2, sd); Y_sd[Y_sd == 0] <- 1
    Xs <- scale(Xd, center = FALSE, scale = X_sd)
    Ys <- scale(Y,  center = FALSE, scale = Y_sd)
  }

  # SigmaInv (optional) from OLS residuals in standardized coordinates
  SigmaInv <- NULL
  if (isTRUE(updateSigma)) {
    B0 <- solve(crossprod(Xs) + diag(1e-8, d), crossprod(Xs, Ys))  # d x k
    R0 <- Ys - Xs %*% B0
    Sig <- crossprod(R0) / nrow(R0)
    if (isTRUE(sigma_diag_only)) {
      SigmaInv <- diag(1 / pmax(diag(Sig), 1e-12), k, k)
    } else {
      sv <- svd(Sig); dd <- pmax(sv$d, 1e-12)
      SigmaInv <- sv$u %*% diag(1 / dd, k) %*% t(sv$u)
    }
  }

  # ----- Stage 1: lasso -----
  W0 <- .make_varp_weights(k, p, diagTF = diagTF)  # d x k
  lambdas1 <- .kkt_lambda_grid_fista(Xs, Ys, W0, SigmaInv, nlambda, lambda_min_ratio)
  lam1 <- .cv_select_lambda_fista(Xs, Ys, W0, lambdas1, SigmaInv, n_folds = fold,
                                  max_iter = max_iter, tol = tol)

  B1 <- fista_lasso_multi_cpp(
    X = Xs, Y = Ys, weights = W0, lambda = lam1,
    SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
    max_iter = max_iter, tol = tol
  )

  # ----- Stage 2: adaptive lasso -----
  W1 <- 1 / pmax(abs(B1), eps_w)
  W1 <- pmin(W1, 1e6)
  if (diagTF) {
    for (ell in seq_len(p)) for (j in seq_len(k)) W1[(ell - 1L) * k + j, j] <- 0
  }

  lambdas2 <- .kkt_lambda_grid_fista(Xs, Ys, W1, SigmaInv, nlambda, lambda_min_ratio)
  lam2 <- .cv_select_lambda_fista(Xs, Ys, W1, lambdas2, SigmaInv, n_folds = fold,
                                  max_iter = max_iter, tol = tol)

  B2 <- fista_lasso_multi_cpp(
    X = Xs, Y = Ys, weights = W1, lambda = lam2,
    SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
    max_iter = max_iter, tol = tol
  )

  # Back-transform to original scale: Phi = t(B) with column scaling
  Phi_lasso  <- diag(Y_sd, k, k) %*% t(B1) %*% diag(1 / X_sd, d, d)
  Phi_Alasso <- diag(Y_sd, k, k) %*% t(B2) %*% diag(1 / X_sd, d, d)

  Phi_ols <- VAR_ols(Yt, p = p, eps = 1e-8)$Phi_hat

  out <- list(
    model = "sVAR", algo = "fista",
    Phi_hat_lasso  = Phi_lasso,
    Phi_hat_Alasso = Phi_Alasso,
    Phi_hat_ols    = Phi_ols,
    lambda_lasso   = lam1,
    lambda_adalasso = lam2,
    lambdas_lasso  = lambdas1,
    lambdas_adalasso = lambdas2,
    p = p, k = k, fold = fold, diagTF = diagTF,
    standardize = standardize,
    SigmaInv = SigmaInv,
    scales = list(X_sd = X_sd, Y_sd = Y_sd)
  )

  if (isTRUE(debiasTF)) {
    fa = VAR_relaxed(Yt, Phi_Alasso, gam = 0.5)
    out$Phi_hat_active  <- fa$Phi_active
    out$Phi_hat_relaxed <- fa$Phi_relaxed;
    out$gam <- gam
    }
  out
}

# ============================================================
# sVHAR (VHAR) : OLS, glmnet, FISTA, debias/relaxed
# ============================================================

# Design as (X_cal, y_cal) with time in columns (legacy convenience)
.check_vhar_bandwidths <- function(bd = 5, bm = 22) {
  if (length(bd) != 1L || length(bm) != 1L || is.na(bd) || is.na(bm)) {
    stop("bd and bm must be non-missing scalars.")
  }
  if (bd != as.integer(bd) || bm != as.integer(bm)) {
    stop("bd and bm must be positive integers.")
  }
  bd <- as.integer(bd)
  bm <- as.integer(bm)
  if (bd < 1L || bm < 1L) stop("bd and bm must be positive integers.")
  if (bd > bm) stop("Require bd <= bm for VHAR bandwidths.")
  list(bd = bd, bm = bm)
}

.vhar_design_cal <- function(Yt, bd = 5, bm = 22) {
  bw <- .check_vhar_bandwidths(bd = bd, bm = bm)
  if (exists("vhar_design_cpp", mode = "function")) {
    des <- vhar_design_cpp(Yt, bd = bw$bd, bm = bw$bm)
    X_cal <- t(des$X_design)  # (3q) x n
    y_cal <- t(des$Y_resp)    # q x n
    return(list(X_cal = X_cal, y_cal = y_cal))
  }
  # fallback: use R routines from previous library
  Yt_tr <- t(Yt)
  X_cal <- VHAR_X_matrix(Yt_tr, bd = bw$bd, bm = bw$bm)
  y_cal <- VHAR_y_matrix(Yt_tr, bm = bw$bm)
  list(X_cal = X_cal, y_cal = y_cal)
}

#' OLS fit for VHAR
#'
#' Fits the vector heterogeneous autoregressive (VHAR) model with (D, W, M)
#' regressors: the 1-day lag, the \code{bd}-day average, and the \code{bm}-day average.
#' The default bandwidths are \code{bd = 5} and \code{bm = 22}. Requires
#' \code{ncol(Yt) > bm}.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param bd Integer bandwidth for the middle-horizon average (default weekly bandwidth).
#' @param bm Integer bandwidth for the long-horizon average (default monthly bandwidth).
#'
#' @return A list with
#' \itemize{
#'   \item \code{Phi_hat} (and alias \code{Phi_hat_ols}): \eqn{q \times (3q)} coefficient matrix,
#'   \item \code{D_hat}, \code{W_hat}, \code{M_hat}: the \eqn{q\times q} blocks of \code{Phi_hat}.
#' }
#'
#' @examples
#' \dontrun{
#' fit <- VHAR_ols(Yt)
#' fit2 <- VHAR_ols(Yt, bd = 3, bm = 9)
#' dim(fit$Phi_hat)
#' }
#' @seealso \code{\link{VHAR_adalasso}}, \code{\link{VHAR_adalasso_fista}}
#' @export
VHAR_ols <- function(Yt, bd = 5, bm = 22) {
  TT <- ncol(Yt)
  q  <- nrow(Yt)
  bw <- .check_vhar_bandwidths(bd = bd, bm = bm)
  if (TT <= bw$bm) stop("Need ncol(Yt) > bm for VHAR.")

  des <- .vhar_design_cal(Yt, bd = bw$bd, bm = bw$bm)
  X_cal <- des$X_cal
  y_cal <- des$y_cal

  eps <- 1e-8
  XXt <- X_cal %*% t(X_cal) + eps * diag(1, nrow(X_cal))
  Phi_hat <- y_cal %*% t(X_cal) %*% solve(XXt)

  list(Phi_hat = Phi_hat,
       Phi_hat_ols = Phi_hat,
       D_hat = Phi_hat[, 1:q, drop = FALSE],
       W_hat = Phi_hat[, (q + 1):(2 * q), drop = FALSE],
       M_hat = Phi_hat[, (2 * q + 1):(3 * q), drop = FALSE],
       bd = bw$bd,
       bm = bw$bm)
}

# Faster VHAR design (kept as fallback / utility)
#' VHAR design matrix constructor (X)
#'
#' Constructs the stacked VHAR regressor matrix \eqn{X_{\mathrm{cal}}} from a
#' time-by-variable matrix \code{Yt_tr} (time in rows, variables in columns).
#' The output stacks the (D, W, M) blocks and has dimension \eqn{(3q) \times (T-bm)}.
#'
#' @param Yt_tr Numeric matrix of dimension \eqn{T \times q} (time in rows).
#' @param bd Integer bandwidth for the middle-horizon average.
#' @param bm Integer bandwidth for the long-horizon average.
#'
#' @return A numeric matrix \eqn{(3q) \times (T-bm)}.
#'
#' @seealso \code{\link{VHAR_y_matrix}}
#' @keywords internal
VHAR_X_matrix <- function(Yt_tr, bd = 5, bm = 22) {
  TT <- nrow(Yt_tr)
  q  <- ncol(Yt_tr)
  bw <- .check_vhar_bandwidths(bd = bd, bm = bm)
  if (TT <= bw$bm) stop("Need TT > bm.")
  if (anyNA(Yt_tr)) stop("Yt_tr contains NA; handle/impute before VHAR construction.")

  D <- t(Yt_tr[bw$bm:(TT - 1), , drop = FALSE])
  cs <- rbind(rep(0, q), apply(Yt_tr, 2, cumsum))

  end_w   <- bw$bm:(TT - 1)
  start_w <- (bw$bm - bw$bd + 1):(TT - bw$bd)
  Wsum <- cs[end_w + 1, , drop = FALSE] - cs[start_w, , drop = FALSE]
  W <- t(Wsum / bw$bd)

  end_m   <- bw$bm:(TT - 1)
  start_m <- 1:(TT - bw$bm)
  Msum <- cs[end_m + 1, , drop = FALSE] - cs[start_m, , drop = FALSE]
  M <- t(Msum / bw$bm)

  rbind(D, W, M)
}

#' VHAR response matrix constructor (y)
#'
#' Constructs the VHAR response matrix \eqn{y_{\mathrm{cal}}} from a time-by-variable
#' matrix \code{Yt_tr} (time in rows, variables in columns). The first \code{bm}
#' observations are dropped to align with the (D, W, M) regressors.
#'
#' @param Yt_tr Numeric matrix of dimension \eqn{T \times q}.
#' @param bm Integer bandwidth for the long-horizon average.
#'
#' @return A numeric matrix \eqn{q \times (T-bm)}.
#'
#' @seealso \code{\link{VHAR_X_matrix}}
#' @keywords internal
VHAR_y_matrix <- function(Yt_tr, bm = 22) {
  bw <- .check_vhar_bandwidths(bd = 1, bm = bm)
  t(Yt_tr)[, -(1:bw$bm), drop = FALSE]
}

# Residual Sigma for VHAR given y_cal (q x n), X_cal (3q x n), Phi (q x 3q)
#' Residual covariance for VHAR
#'
#' Computes residuals and the residual covariance matrix for a supplied VHAR
#' coefficient matrix \code{Phi_hat} given the design \code{x} and response \code{y}.
#'
#' @param y Response matrix \eqn{q \times n}.
#' @param x Design matrix \eqn{(3q) \times n}.
#' @param Phi_hat Coefficient matrix \eqn{q \times (3q)}.
#'
#' @return A list with residuals \code{Resi} and covariance \code{Sigma_z}.
#' @keywords internal
VHAR_sigma <- function(y, x, Phi_hat) {
  Resi <- y - Phi_hat %*% x
  Sigma_z <- Resi %*% t(Resi) / ncol(Resi)
  list(Resi = Resi, Sigma_z = Sigma_z)
}

# Active-set refit (VHAR) in original (small) design coordinates
#' Active-set refit for sparse VHAR estimates
#'
#' Performs equation-by-equation active-set refitting for VHAR in the original
#' (D, W, M) design coordinates. If \code{diagTF} or \code{force_diag} is \code{TRUE},
#' the self-lag coefficients in each block are always included in the refit.
#'
#' @param X_cal VHAR regressor matrix \eqn{(3q) \times n}.
#' @param y_cal VHAR response matrix \eqn{q \times n}.
#' @param Phi_sparse Sparse coefficient matrix \eqn{q \times (3q)} whose support defines the active set.
#' @param diagTF Logical; always include self-lags in the refit.
#' @param force_diag Logical; synonym for enforcing diagonal self-lags.
#' @param eps Ridge stabilization for refitting.
#'
#' @return A dense coefficient matrix \eqn{q \times (3q)}.
#'
#' @seealso \code{\link{VHAR_relaxed}}
#' @keywords internal
VHAR_active_refit <- function(X_cal, y_cal, Phi_sparse,
                              diagTF = TRUE, force_diag = TRUE,
                              eps = 1e-8) {
  q <- nrow(y_cal)
  d <- nrow(X_cal)
  Phi_sparse <- as.matrix(Phi_sparse)
  if (nrow(Phi_sparse) != q || ncol(Phi_sparse) != d) stop("Phi_sparse must be q x (3q).")

  Phi_ref <- matrix(0, q, d)
  for (j in seq_len(q)) {
    ids <- which(Phi_sparse[j, ] != 0)
    if (isTRUE(diagTF) || isTRUE(force_diag)) {
      # always keep self-lags in D/W/M blocks
      ids <- sort(unique(c(ids, j, q + j, 2 * q + j)))
    }
    Xs <- t(X_cal[ids, , drop = FALSE])  # n x |ids|
    yj <- as.numeric(y_cal[j, ])
    XtX <- crossprod(Xs) + diag(eps, ncol(Xs))
    Xty <- crossprod(Xs, yj)
    bj <- tryCatch(solve(XtX, Xty), error = function(e) qr.coef(qr(Xs), yj))
    bj[is.na(bj)] <- 0
    Phi_ref[j, ids] <- as.numeric(bj)
  }
  Phi_ref
}

#' Relaxed (debiasing) combination for VHAR coefficients
#'
#' Forms the relaxed estimate
#' \deqn{\Phi_{\text{relaxed}} = \gamma \Phi_{\text{sparse}} + (1-\gamma)\Phi_{\text{active}}.}
#' The active-set refit is computed internally from \code{Yt} and \code{Phi_hat}.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param Phi_hat Sparse coefficient matrix \eqn{q \times (3q)}.
#' @param gam Mixing weight \eqn{\gamma \in [0,1]}.
#' @param diagTF Logical; passed to the active-set refit (include self-lags).
#' @param force_diag Logical; synonym for enforcing diagonal self-lags in the refit.
#' @param eps_refit Ridge stabilization for refitting.
#' @param bd Integer bandwidth for the middle-horizon average.
#' @param bm Integer bandwidth for the long-horizon average.
#'
#' @return A coefficient matrix \eqn{q \times (3q)}.
#' @export
VHAR_relaxed <- function(Yt, Phi_hat, gam = 0.5,
                         diagTF = TRUE, force_diag = TRUE, eps_refit = 1e-8,
                         bd = 5, bm = 22) {
  if (gam < 0 || gam > 1) stop("gam must be in [0,1].")
  bw <- .check_vhar_bandwidths(bd = bd, bm = bm)
  des <- .vhar_design_cal(Yt, bd = bw$bd, bm = bw$bm); ff=list();
  ff$Phi_active <- VHAR_active_refit(des$X_cal, des$y_cal, Phi_hat,
                                  diagTF = diagTF, force_diag = force_diag, eps = eps_refit)
  ff$Phi_relaxed = gam * Phi_hat + (1 - gam) * ff$Phi_active
  ff$bd <- bw$bd
  ff$bm <- bw$bm
  return(ff)
}

# VHAR adaptive lasso via glmnet (vectorized)
#' Sparse VHAR via lasso and adaptive lasso (glmnet)
#'
#' Estimates sparse VHAR coefficients using lasso and adaptive lasso with \pkg{glmnet}.
#' Optionally applies a whitening matrix derived from a residual covariance estimate.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param fold Number of (blocked) CV folds.
#' @param diagTF Logical; if \code{TRUE}, self-lags in each (D, W, M) block are unpenalized.
#' @param updateSigma Logical; if \code{TRUE}, update whitening matrix from residual covariance.
#' @param whiten Whitening type when \code{updateSigma=TRUE}: \code{"diag"} or \code{"full"}.
#' @param relaxTF Logical; enable relaxed refit in glmnet CV (when supported).
#' @param debiasTF Logical; if \code{TRUE}, compute active-set refit and relaxed estimate.
#' @param gam Mixing weight for relaxed estimate.
#' @param standardize Passed to glmnet.
#' @param bd Integer bandwidth for the middle-horizon average.
#' @param bm Integer bandwidth for the long-horizon average.
#'
#' @return A list containing sparse and OLS estimates, selected lambdas, residual covariance,
#' and (if requested) active/relaxed outputs. For backward compatibility,
#' aliases \code{Phi_lasso_hat}, \code{Phi_Alasso_hat}, \code{Phi_ols_hat} are included.
#'
#' @examples
#' \dontrun{
#' fit <- VHAR_adalasso(Yt, fold = 5)
#' }
#'
#' @seealso \code{\link{VHAR_adalasso_fista}}, \code{\link{VHAR_active_refit}}
#' @export
VHAR_adalasso <- function(Yt, fold = 10,
                          diagTF = TRUE,
                          updateSigma = FALSE,
                          whiten = c("diag", "full"),
                          relaxTF = TRUE,
                          debiasTF = FALSE,
                          gam = 0.5,
                          standardize = TRUE,
                          bd = 5,
                          bm = 22) {

  if (!requireNamespace("Matrix", quietly = TRUE)) stop("Package 'Matrix' is required.")
  whiten <- match.arg(whiten)

  TT <- ncol(Yt); q <- nrow(Yt)
  bw <- .check_vhar_bandwidths(bd = bd, bm = bm)
  if (TT <= bw$bm) stop("Need ncol(Yt) > bm for VHAR.")

  des <- .vhar_design_cal(Yt, bd = bw$bd, bm = bw$bm)
  X_cal <- des$X_cal
  y_cal <- des$y_cal
  n <- ncol(y_cal)
  d <- nrow(X_cal)

  eps <- 1e-8
  XXt <- X_cal %*% t(X_cal) + eps * diag(1, nrow(X_cal))
  Phi_hat0 <- y_cal %*% t(X_cal) %*% solve(XXt)

  Iq <- Matrix::Diagonal(q)
  X_design <- t(X_cal)                         # n x d
  new_X <- Matrix::kronecker(Matrix::Matrix(X_design, sparse = FALSE), Iq)
  new_y <- as.numeric(y_cal)

  hal <- diag(q)
  Sigma_z <- NULL
  if (isTRUE(updateSigma)) {
    Sigma_z <- VHAR_sigma(y_cal, X_cal, Phi_hat0)$Sigma_z
    hal <- .sig_invsqrt(Sigma_z, whiten = whiten)
    adjSig <- Matrix::kronecker(Matrix::Diagonal(n), Matrix::Matrix(hal, sparse = FALSE))
    new_X <- adjSig %*% new_X
    new_y <- as.numeric(adjSig %*% Matrix::Matrix(new_y, ncol = 1))
  }

  exclude <- if (diagTF) .diag_exclude_idx_vhar(q) else NULL

  pp <- adalasso.glmnet(
    X = new_X, y = new_y,
    nf = fold, alpha = 1,
    relaxTF = relaxTF,
    exclude = exclude,
    standardize = standardize
  )

  Phi_lasso  <- matrix(pp$lasso,  nrow = q)
  Phi_Alasso <- matrix(pp$Alasso, nrow = q)

  out <- list(
    model = "sVHAR", algo = "glmnet",
    Phi_hat_ols    = Phi_hat0,
    Phi_hat_lasso  = Phi_lasso,
    Phi_hat_Alasso = Phi_Alasso,
    Sigma_z        = Sigma_z,
    hal            = hal,
    q = q, TT = TT, fold = fold, diagTF = diagTF,
    bd = bw$bd, bm = bw$bm,
    lambda_lasso    = pp$lambda_lasso,
    lambda_adalasso = pp$lambda_adalasso,
    fit_lasso       = pp$fit_lasso,
    fit_adalasso    = pp$fit_adalasso
  )

  # Backward-compatible aliases (old field names in VHAR-library1.R)
  out$Phi_lasso_hat  <- out$Phi_hat_lasso
  out$Phi_Alasso_hat <- out$Phi_hat_Alasso
  out$Phi_ols_hat    <- out$Phi_hat_ols

  if (isTRUE(debiasTF)) {
    fa = VHAR_relaxed(Yt, Phi_Alasso, gam = gam, bd = bw$bd, bm = bw$bm)
    out$Phi_hat_active  <- fa$Phi_active
    out$Phi_hat_relaxed <- fa$Phi_relaxed;
    out$gam <- gam
  }

  out
}

# VHAR via FISTA (Rcpp): lasso -> adaptive lasso
#' Sparse VHAR via FISTA (compiled back-end)
#'
#' Estimates VHAR coefficients using a compiled multi-response FISTA solver.
#' Depending on \code{type}, it fits lasso, adaptive lasso, or both. Lambda is chosen
#' by blocked cross-validation on a KKT-based lambda grid unless supplied explicitly.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param type One of \code{"adaptive"}, \code{"lasso"}, or \code{"both"}.
#' @param fold Number of blocked CV folds.
#' @param lambda Optional scalar lambda; if provided, CV is skipped.
#' @param lambda_seq Optional lambda grid; if \code{NULL}, a grid is constructed.
#' @param nlambda Grid size when constructing a lambda grid.
#' @param lambda_min_ratio Minimum/maximum ratio for lambda grid construction. If \code{NULL}, a default is used.
#' @param diagTF Logical; if \code{TRUE}, self-lags in each (D, W, M) block are unpenalized.
#' @param updateSigma Logical; if \code{TRUE}, include \code{SigmaInv} in the quadratic loss.
#' @param sigma_diag_only Logical; if \code{TRUE}, use only diagonal covariance in \code{SigmaInv}.
#' @param max_iter Maximum FISTA iterations.
#' @param tol Convergence tolerance.
#' @param w_eps Stabilization for adaptive-lasso weights.
#' @param w_cap Cap for adaptive-lasso weights.
#' @param bd Integer bandwidth for the middle-horizon average.
#' @param bm Integer bandwidth for the long-horizon average.
#'
#' @return A list with metadata plus fitted coefficients and selected lambdas.
#' Components \code{Phi_hat_lasso} and/or \code{Phi_hat_Alasso} are included depending on \code{type}.
#' For backward compatibility, aliases \code{Phi_lasso_hat} and \code{Phi_Alasso_hat} are included.
#'
#' @examples
#' \dontrun{
#' fit <- VHAR_adalasso_fista(Yt, type = "both", fold = 5)
#' }
#'
#' @seealso \code{\link{VHAR_adalasso}}, \code{\link{VHAR_ols}}
#' @export
VHAR_adalasso_fista <- function(
    Yt,
    type = c("adaptive", "lasso", "both"),
    fold = 10,
    lambda = NULL,
    lambda_seq = NULL,
    nlambda = 100,
    lambda_min_ratio = NULL,
    diagTF = TRUE,
    updateSigma = FALSE,
    sigma_diag_only = TRUE,
    max_iter = 1000,
    tol = 1e-6,
    w_eps = 1e-7,
    w_cap = 1e6,
    bd = 5,
    bm = 22
) {
  type <- match.arg(type)
  if (!exists("fista_lasso_multi_cpp", mode = "function")) {
    stop("fista_lasso_multi_cpp not found. Compile src/svar_suite.cpp first.")
  }

  q  <- nrow(Yt)
  TT <- ncol(Yt)
  bw <- .check_vhar_bandwidths(bd = bd, bm = bm)
  if (TT <= bw$bm) stop("Need ncol(Yt) > bm for VHAR design.")

  if (exists("vhar_design_cpp", mode = "function")) {
    des <- vhar_design_cpp(Yt, bd = bw$bd, bm = bw$bm)
    X_design <- as.matrix(des$X_design)   # n x d
    Y_resp   <- as.matrix(des$Y_resp)     # n x q
  } else {
    des_cal <- .vhar_design_cal(Yt, bd = bw$bd, bm = bw$bm)
    X_design <- t(des_cal$X_cal)
    Y_resp   <- t(des_cal$y_cal)
  }
  n <- nrow(X_design)
  d <- ncol(X_design)

  SigmaInv <- NULL
  if (updateSigma) {
    # OLS residuals -> SigmaInv (optionally diagonal only)
    B0 <- solve(crossprod(X_design) + diag(1e-8, d), crossprod(X_design, Y_resp))
    R0 <- Y_resp - X_design %*% B0
    Sig <- crossprod(R0) / nrow(R0)
    if (sigma_diag_only) {
      SigmaInv <- diag(1 / pmax(diag(Sig), 1e-12), q, q)
    } else {
      sv <- svd(Sig); dd <- pmax(sv$d, 1e-12)
      SigmaInv <- sv$u %*% diag(1 / dd, q) %*% t(sv$u)
    }
  }

  W0 <- matrix(1, d, q)
  if (diagTF && d == 3 * q) {
    for (j in seq_len(q)) {
      W0[j, j]         <- 0
      W0[q + j, j]     <- 0
      W0[2 * q + j, j] <- 0
    }
  }

  fit_cv <- function(W, lambda_seq_override = NULL) {
    lambdas <- lambda_seq_override
    if (is.null(lambdas)) {
      lambdas <- .kkt_lambda_grid_fista(
        X_design, Y_resp, W,
        SigmaInv = SigmaInv,
        nlambda = nlambda, lambda_min_ratio = lambda_min_ratio
      )
    }
    lam_star <- .cv_select_lambda_fista(
      X_design, Y_resp, W, lambdas, SigmaInv, n_folds = fold,
      max_iter = max_iter, tol = tol, penalize_vhar_selflags = !diagTF
    )
    Bhat <- fista_lasso_multi_cpp(
      X = X_design, Y = Y_resp, weights = W, lambda = lam_star,
      SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
      max_iter = max_iter, tol = tol,
      penalize_vhar_selflags = !diagTF
    )
    list(Phi = t(Bhat), lambda = lam_star, lambdas = lambdas)
  }

  fit_fixed <- function(W, lam) {
    Bhat <- fista_lasso_multi_cpp(
      X = X_design, Y = Y_resp, weights = W, lambda = lam,
      SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
      max_iter = max_iter, tol = tol,
      penalize_vhar_selflags = !diagTF
    )
    list(Phi = t(Bhat), lambda = lam)
  }

  out <- list(
    model = "sVHAR", algo = "fista",
    type = type, q = q, TT = TT, n = n, d = d,
    diagTF = diagTF, updateSigma = updateSigma, SigmaInv = SigmaInv,
    bd = bw$bd, bm = bw$bm,
    lambda_rule = "kkt_fista"
  )

  if (type %in% c("lasso", "both")) {
    fitL <- if (!is.null(lambda)) fit_fixed(W0, lambda) else fit_cv(W0, lambda_seq)
    out$Phi_hat_lasso <- fitL$Phi
    out$lambda_lasso  <- fitL$lambda
    if (is.null(lambda)) out$lambdas_lasso <- fitL$lambdas
    out$Phi_lasso_hat <- out$Phi_hat_lasso
  }

  if (type %in% c("adaptive", "both")) {
    # Stage-1 lasso (needed for weights)
    fitL0 <- if (type == "adaptive" && !is.null(out$Phi_hat_lasso)) {
      list(Phi = out$Phi_hat_lasso, lambda = out$lambda_lasso)
    } else {
      if (!is.null(lambda)) fit_fixed(W0, lambda) else fit_cv(W0, lambda_seq)
    }

    B1 <- t(fitL0$Phi)  # d x q
    W1 <- 1 / pmax(abs(B1), w_eps)
    W1 <- pmin(W1, w_cap)
    if (diagTF && d == 3 * q) {
      for (j in seq_len(q)) {
        W1[j, j]         <- 0
        W1[q + j, j]     <- 0
        W1[2 * q + j, j] <- 0
      }
    }

    fitA <- if (!is.null(lambda)) fit_fixed(W1, lambda) else fit_cv(W1, lambda_seq)
    out$Phi_hat_Alasso <- fitA$Phi
    out$lambda_adalasso <- fitA$lambda
    if (is.null(lambda)) out$lambdas_adalasso <- fitA$lambdas
    out$Phi_Alasso_hat <- out$Phi_hat_Alasso
  }

  out
}

# ============================================================
# sPVAR (PVAR(1)) : seasonal centering + glmnet / FISTA
# ============================================================

#' Season-specific means for periodic centering
#'
#' Computes season-wise means for a periodic series with period \code{s}.
#' Used internally to center \code{Yt} in periodic VAR procedures.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#'
#' @return Numeric matrix \eqn{q \times s} whose \code{[,j]} is the mean of season \code{j}.
#'
#' @keywords internal
PCstat_mat <- function(Yt, s) {
  q <- nrow(Yt); TT <- ncol(Yt)
  mu <- matrix(0, q, s)
  for (j in seq_len(s)) mu[, j] <- rowMeans(Yt[, seq(j, TT, by = s), drop = FALSE])
  mu
}

# R fallback (rows are observations)
#' Season-specific design matrices for PVAR(1)
#'
#' Constructs the season-specific regression design \code{X} and response \code{Y}
#' for periodic VAR(1) at a given season index.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#' @param season Integer season index in \code{1,\dots,s}.
#'
#' @return A list with
#' \itemize{
#'   \item \code{X}: \eqn{n \times q} lagged predictors,
#'   \item \code{Y}: \eqn{n \times q} responses,
#'   \item \code{id}: integer indices of time points used.
#' }
#'
#' @keywords internal
spvar_design_season_R <- function(Yt, s, season) {
  TT <- ncol(Yt)
  ids <- seq(from = season, to = TT, by = s)
  ids <- ids[ids > 1]
  n <- length(ids)
  if (n <= 1) stop("Not enough observations for season ", season, ".")
  X <- t(Yt[, ids - 1, drop = FALSE])
  Y <- t(Yt[, ids,     drop = FALSE])
  list(X = X, Y = Y, id = ids)
}

.get_season_design <- function(Yt, s, season) {
  if (exists("spvar_design_season_cpp", mode = "function")) {
    spvar_design_season_cpp(Yt, s, season)
  } else {
    spvar_design_season_R(Yt, s, season)
  }
}

#' OLS fit for periodic VAR(1)
#'
#' Fits a periodic VAR(1) model with season period \code{s} by estimating a
#' season-specific transition matrix \eqn{A_m} for each season \eqn{m=1,\dots,s}.
#' The output \code{Phi_hat} stacks the \eqn{A_m} blocks horizontally.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#' @param p Lag order (currently only \code{p=1} is implemented).
#'
#' @return A list with \code{Phi_hat}, a \eqn{q \times (q s)} matrix whose
#' block \code{m} is the \eqn{q\times q} matrix \eqn{A_m}.
#'
#' @export
PVAR_ols <- function(Yt, s, p = 1) {
  TT <- ncol(Yt)
  q <- nrow(Yt)
  if (p != 1) stop("PVAR_ols currently implemented for p=1.")
  Phi_hat <- array(NA_real_, dim = c(q, q * s))
  for (m in seq_len(s)) {
    idx <- which((seq_len(TT) - 1) %% s + 1 == m)[-1]
    Z <- Yt[, idx, drop = FALSE]
    X <- Yt[, (idx - 1), drop = FALSE]
    eps <- 1e-8
    Phi_hat[, (q * (m - 1) + 1):(q * m)] <- solve(X %*% t(X) + eps * diag(1, q)) %*% X %*% t(Z)
  }
  list(Phi_hat = Phi_hat)
}

.get_Ai <- function(Phi, i, q) {
  cols <- ((i - 1) * q + 1):(i * q)
  Phi[, cols, drop = FALSE]
}
.set_Ai <- function(Phi, A, i, q) {
  cols <- ((i - 1) * q + 1):(i * q)
  Phi[, cols] <- A
  Phi
}

# Active-set refit by season (Phi is q x (q*s))
#' Active-set refit for sparse periodic VAR(1) estimates
#'
#' Performs season-by-season equation-wise active-set refitting for a PVAR(1).
#' The active set for each season is defined by nonzeros of the corresponding
#' block of \code{Phi_hat}. If \code{centerTF=TRUE}, the series is season-wise centered
#' before refitting.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#' @param Phi_hat Sparse coefficient matrix \eqn{q \times (q s)}.
#' @param centerTF Logical; season-wise centering prior to refit.
#' @param diagTF Logical; include diagonal self-lags in the refit.
#' @param force_diag Logical; enforce inclusion of diagonal self-lags.
#' @param eps Ridge stabilization for refitting.
#'
#' @return A dense coefficient matrix \eqn{q \times (q s)}.
#'
#' @seealso \code{\link{sPVAR_relaxed}}
#' @keywords internal
sPVAR_active_refit <- function(Yt, s, Phi_hat,
                               centerTF = TRUE,
                               diagTF = TRUE,
                               force_diag = TRUE,
                               eps = 1e-8) {
  Phi_hat <- as.matrix(Phi_hat)
  q <- nrow(Phi_hat)
  if (ncol(Phi_hat) != q * s) stop("Phi_hat must be q x (q*s) for PVAR(1).")

  TT <- ncol(Yt)
  if (centerTF) {
    mu <- PCstat_mat(Yt, s)
    season_id <- ((seq_len(TT) - 1) %% s) + 1
    Yc <- Yt - mu[, season_id, drop = FALSE]
  } else {
    Yc <- Yt
  }

  Phi_out <- matrix(0, q, q * s)
  for (i in seq_len(s)) {
    Ahat <- .get_Ai(Phi_hat, i, q)
    des <- .get_season_design(Yc, s, i)
    X <- as.matrix(des$X)
    Y <- as.matrix(des$Y)

    Aref <- matrix(0, q, q)
    for (j in seq_len(q)) {
      ids <- which(Ahat[j, ] != 0)
      if (force_diag || diagTF) ids <- sort(unique(c(ids, j)))
      if (length(ids) == 0) next
      Xsub <- X[, ids, drop = FALSE]
      yj <- Y[, j]
      XtX <- crossprod(Xsub) + diag(eps, ncol(Xsub))
      Xty <- crossprod(Xsub, yj)
      bj <- tryCatch(solve(XtX, Xty), error = function(e) qr.coef(qr(Xsub), yj))
      bj[is.na(bj)] <- 0
      Aref[j, ids] <- as.numeric(bj)
    }
    Phi_out <- .set_Ai(Phi_out, Aref, i, q)
  }
  Phi_out
}

#' Relaxed (debiasing) combination for periodic VAR coefficients
#'
#' Forms a relaxed periodic VAR estimate by combining the sparse estimate
#' \code{Phi_hat} with its active-set refit.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#' @param Phi_hat Sparse coefficient matrix \eqn{q \times (q s)}.
#' @param gam Mixing weight in \eqn{[0,1]}.
#' @param centerTF Logical; season-wise centering prior to refit.
#' @param diagTF Logical; include diagonal self-lags in the refit.
#' @param force_diag Logical; enforce inclusion of diagonal self-lags.
#' @param eps Ridge stabilization for refitting.
#'
#' @return A coefficient matrix \eqn{q \times (q s)}.
#' @export
sPVAR_relaxed <- function(Yt, s, Phi_hat, gam = 0.5,
                          centerTF = TRUE,
                          diagTF = TRUE,
                          force_diag = TRUE,
                          eps = 1e-8) {
  if (gam < 0 || gam > 1) stop("gam must be in [0,1].")
  Phi_hat <- as.matrix(Phi_hat); ff=list();
  ff$Phi_active <- sPVAR_active_refit(Yt, s, Phi_hat,
                                   centerTF = centerTF,
                                   diagTF = diagTF,
                                   force_diag = force_diag,
                                   eps = eps)
  ff$Phi_relaxed = gam * Phi_hat + (1 - gam) * ff$Phi_active;
  return(ff)
}

# sPVAR via FISTA (Rcpp): per-season lasso -> adaptive lasso
#' Sparse periodic VAR(1) via FISTA (compiled back-end)
#'
#' Estimates a sparse periodic VAR(1) with season period \code{s} using a compiled
#' multi-response FISTA solver, optionally iterating outer updates. Depending on
#' \code{type}, fits lasso, adaptive lasso, or both.
#'
#' If \code{centerTF=TRUE}, the series is season-wise centered before estimation.
#' If \code{diagTF=TRUE}, diagonal self-lags are treated as unpenalized.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#' @param p Lag order (currently only \code{p=1} is implemented).
#' @param type One of \code{"adaptive"}, \code{"lasso"}, or \code{"both"}.
#' @param fold Number of blocked CV folds for lambda selection.
#' @param diagTF Logical; unpenalize diagonal self-lags.
#' @param centerTF Logical; season-wise centering.
#' @param updateSigma Logical; update season-wise \code{SigmaInv}.
#' @param sigma_diag_only Logical; if \code{TRUE}, use only diagonal covariance in \code{SigmaInv}.
#' @param nlambda Lambda grid size.
#' @param lambda_min_ratio Minimum/maximum ratio for lambda grid. If \code{NULL}, a default is used.
#' @param max_outer Maximum outer iterations.
#' @param tol_outer Outer convergence tolerance.
#' @param max_iter Maximum inner FISTA iterations.
#' @param tol Inner convergence tolerance.
#' @param w_eps Stabilization for adaptive weights.
#' @param w_cap Cap for adaptive weights.
#' @param debiasTF Logical; compute active-set refit for \code{debias_target}.
#' @param relaxedTF Logical; additionally compute relaxed estimate.
#' @param gam Mixing weight for relaxed estimate.
#' @param debias_target Which sparse target to refit: \code{"Alasso"} or \code{"lasso"}.
#' @param force_diag Logical; enforce diagonal inclusion in active refit.
#' @param eps_refit Ridge stabilization used in the active refit.
#'
#' @return A list with sparse estimates and iteration diagnostics, including
#' \code{Phi_hat_ols}, \code{Phi_hat_lasso}, \code{Phi_hat_Alasso} (if applicable),
#' selected lambdas, season-wise \code{SigmaInv}, and optional active/relaxed outputs.
#'
#' @export
sPVAR_adalasso_fista <- function(Yt, s, p = 1,
                                 type = c("adaptive", "lasso", "both"),
                                 fold = 10,
                                 diagTF = TRUE,
                                 centerTF = TRUE,
                                 updateSigma = TRUE,
                                 sigma_diag_only = FALSE,
                                 nlambda = 100,
                                 lambda_min_ratio = NULL,
                                 max_outer = 5,
                                 tol_outer = 1e-2,
                                 max_iter = 1000,
                                 tol = 1e-6,
                                 w_eps = 1e-7,
                                 w_cap = 1e6,
                                 debiasTF = FALSE,
                                 relaxedTF = FALSE,
                                 gam = 0.5,
                                 debias_target = c("Alasso", "lasso"),
                                 force_diag = TRUE,
                                 eps_refit = 1e-8) {

  type <- match.arg(type)
  debias_target <- match.arg(debias_target)
  if (p != 1) stop("sPVAR_adalasso_fista is implemented for p=1 only.")
  if (!exists("fista_lasso_multi_cpp", mode = "function") && !exists("fista_spvar_multi_cpp", mode = "function")) {
    stop("FISTA solver not found. Compile src/svar_suite.cpp first.")
  }

  q  <- nrow(Yt)
  TT <- ncol(Yt)

  # seasonal centering
  if (centerTF) {
    mt <- PCstat_mat(Yt, s)
    season_id <- ((seq_len(TT) - 1) %% s) + 1
    Yc <- Yt - mt[, season_id, drop = FALSE]
  } else {
    Yc <- Yt
  }

  Phi_ols <- PVAR_ols(Yt, s, p = 1)$Phi_hat
  Phi0 <- Phi_ols

  lambda_lasso <- rep(NA_real_, s)
  lambda_adalasso <- rep(NA_real_, s)
  Sigma_list <- vector("list", s)

  iter <- 1L
  diff <- Inf
  Phi_lasso_last <- matrix(0, q, q * s)

  while (diff >= tol_outer && iter <= max_outer) {
    Phi_lasso_new <- matrix(0, q, q * s)
    Phi_ada_new   <- matrix(0, q, q * s)

    for (i in seq_len(s)) {
      cols_i <- ((i - 1) * q + 1):(i * q)
      A_i <- Phi0[, cols_i, drop = FALSE]

      des_i <- .get_season_design(Yc, s, i)
      X <- as.matrix(des_i$X)  # n x q
      Y <- as.matrix(des_i$Y)  # n x q

      SigmaInv <- NULL
      if (updateSigma) {
        R0 <- Y - X %*% t(A_i)
        Sig <- crossprod(R0) / nrow(R0)
        if (sigma_diag_only) {
          d0 <- pmax(diag(Sig), 1e-12)
          SigmaInv <- diag(1 / d0, q, q)
        } else {
          sv <- svd(Sig); dd <- pmax(sv$d, 1e-12)
          SigmaInv <- sv$u %*% diag(1 / dd, q) %*% t(sv$u)
        }
      }
      Sigma_list[[i]] <- SigmaInv

      # ----- stage-1 lasso -----
      W0 <- matrix(1, q, q)
      if (diagTF) diag(W0) <- 0

      lambdas0 <- .kkt_lambda_grid_fista(X, Y, W0, SigmaInv, nlambda, lambda_min_ratio)
      lam0 <- .cv_select_lambda_fista(X, Y, W0, lambdas0, SigmaInv, n_folds = fold,
                                      max_iter = max_iter, tol = tol)

      B_lasso <- if (exists("fista_lasso_multi_cpp", mode = "function")) {
        fista_lasso_multi_cpp(
          X = X, Y = Y, weights = W0, lambda = lam0,
          SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
          max_iter = max_iter, tol = tol
        )
      } else {
        fista_spvar_multi_cpp(
          X = X, Y = Y, weights = W0, lambda = lam0,
          SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
          max_iter = max_iter, tol = tol
        )
      }

      Phi_lasso_new[, cols_i] <- t(B_lasso)
      lambda_lasso[i] <- lam0
      if (type == "lasso") next

      # ----- stage-2 adaptive lasso -----
      W1 <- 1 / pmax(abs(B_lasso), w_eps)
      W1 <- pmin(W1, w_cap)
      if (diagTF) diag(W1) <- 0

      lambdas1 <- .kkt_lambda_grid_fista(X, Y, W1, SigmaInv, nlambda, lambda_min_ratio)
      lam1 <- .cv_select_lambda_fista(X, Y, W1, lambdas1, SigmaInv, n_folds = fold,
                                      max_iter = max_iter, tol = tol)

      B_ada <- if (exists("fista_lasso_multi_cpp", mode = "function")) {
        fista_lasso_multi_cpp(
          X = X, Y = Y, weights = W1, lambda = lam1,
          SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
          max_iter = max_iter, tol = tol
        )
      } else {
        fista_spvar_multi_cpp(
          X = X, Y = Y, weights = W1, lambda = lam1,
          SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
          max_iter = max_iter, tol = tol
        )
      }

      Phi_ada_new[, cols_i] <- t(B_ada)
      lambda_adalasso[i] <- lam1
    }

    Phi_lasso_last <- Phi_lasso_new

    if (type == "lasso") {
      diff <- sum((Phi0 - Phi_lasso_new)^2)
      Phi0 <- Phi_lasso_new
    } else {
      diff <- sum((Phi0 - Phi_ada_new)^2)
      Phi0 <- Phi_ada_new
    }
    iter <- iter + 1L
  }

  out <- list(
    model = "sPVAR", algo = "fista",
    Phi_hat_ols = Phi_ols,
    Phi_hat_lasso = Phi_lasso_last,
    Phi_hat_Alasso = if (type == "lasso") NULL else Phi0,
    lambda_lasso = lambda_lasso,
    lambda_adalasso = if (type == "lasso") NULL else lambda_adalasso,
    SigmaInv = Sigma_list,
    iter = iter - 1L,
    diff = diff
  )

  # backward-compatibility aliases (old names in sPVAR-library2.R)
  out$lam_lasso <- out$lambda_lasso
  out$lam_adalasso <- out$lambda_adalasso

  if (debiasTF || relaxedTF) {
    target_Phi <- if (debias_target == "Alasso" && !is.null(out$Phi_hat_Alasso)) {
      out$Phi_hat_Alasso
    } else {
      out$Phi_hat_lasso
    }
    Phi_active <- sPVAR_active_refit(Yt, s, target_Phi,
                                     centerTF = centerTF,
                                     diagTF = diagTF,
                                     force_diag = force_diag,
                                     eps = eps_refit)
    out$Phi_hat_active <- Phi_active
    if (relaxedTF) {
      out$Phi_hat_relaxed <- gam * target_Phi + (1 - gam) * Phi_active
      out$gam <- gam
    }
  }

  out
}

# sPVAR via glmnet adaptive lasso (vectorized by season)
#' Sparse periodic VAR(1) via lasso and adaptive lasso (glmnet)
#'
#' Estimates a sparse periodic VAR(1) with season period \code{s} using \pkg{glmnet}
#' season-by-season. The procedure includes optional outer iterations that update
#' season-specific estimates until convergence.
#'
#' @param Yt Numeric matrix \eqn{q \times T}.
#' @param s Season period.
#' @param p Lag order (currently only \code{p=1} is implemented).
#' @param fold Number of blocked CV folds.
#' @param diagTF Logical; if \code{TRUE}, diagonal self-lags are treated as unpenalized.
#' @param whiten Whitening type used when covariance updates are applied: \code{"diag"} or \code{"full"}.
#' @param relaxTF Logical; enable relaxed refit in glmnet CV (when supported).
#' @param standardize Passed to glmnet.
#' @param max_outer Maximum outer iterations.
#' @param tol_outer Outer convergence tolerance.
#' @param debiasTF Logical; compute active-set refit for \code{debias_target}.
#' @param relaxedTF Logical; additionally compute relaxed estimate.
#' @param gam Mixing weight for relaxed estimate.
#' @param debias_target Which sparse target to refit: \code{"Alasso"} or \code{"lasso"}.
#' @param force_diag Logical; enforce diagonal inclusion in active refit.
#' @param eps_refit Ridge stabilization used in the active refit.
#'
#' @return A list with sparse estimates and iteration diagnostics, including
#' \code{Phi_hat_ols}, \code{Phi_hat_lasso}, \code{Phi_hat_Alasso}, and optional
#' active/relaxed outputs.
#'
#' @export
sPVAR_adalasso <- function(Yt, s, p = 1, fold = 10,
                           diagTF = FALSE,
                           whiten = c("diag", "full"),
                           relaxTF = TRUE,
                           standardize = TRUE,
                           max_outer = 5,
                           tol_outer = 0.01,
                           debiasTF = FALSE,
                           relaxedTF = FALSE,
                           gam = 0.5,
                           debias_target = c("Alasso", "lasso"),
                           force_diag = TRUE,
                           eps_refit = 1e-8) {

  if (!requireNamespace("Matrix", quietly = TRUE)) stop("Package 'Matrix' is required.")
  whiten <- match.arg(whiten)
  debias_target <- match.arg(debias_target)
  if (p != 1) stop("sPVAR_adalasso currently implemented for p=1 only.")

  q <- nrow(Yt)
  TT <- ncol(Yt)

  # seasonal centering
  mt <- PCstat_mat(Yt, s)
  season_id <- ((seq_len(TT) - 1) %% s) + 1
  Yc <- Yt - mt[, season_id, drop = FALSE]

  Phi_ols <- PVAR_ols(Yt, s, p = 1)$Phi_hat
  Phi0 <- Phi_ols
  iter <- 1L
  diff <- Inf

  while (diff >= tol_outer && iter <= max_outer) {
    Phi_lasso <- matrix(0, q, q * s)
    Phi_Alasso <- matrix(0, q, q * s)

    for (i in seq_len(s)) {
      id <- which((seq_len(TT) - 1) %% s + 1 == i)
      id <- id[id > 1]
      T3 <- length(id)
      if (T3 <= 1) stop("Not enough observations in season ", i, " after lag removal.")

      cols_i <- ((i - 1) * q + 1):(i * q)
      A_i <- Phi0[, cols_i, drop = FALSE]

      # Construct per-season matrices in legacy format:
      #   y_cal : q x T3, x_cal : q x T3 (lagged)
      Ymat <- Yc[, id, drop = FALSE]
      Z <- Yc[, (id - 1), drop = FALSE]

      # OLS + Sigma whitening (optional)
      eps <- 1e-8
      XXt <- Z %*% t(Z) + eps * diag(1, q)
      A_ols <- Ymat %*% t(Z) %*% solve(XXt)

      Sigma_z <- (Ymat - A_ols %*% Z) %*% t(Ymat - A_ols %*% Z) / T3
      halM <- .sig_invsqrt(Sigma_z, whiten = whiten)

      # Vectorize: (T3*q) x (q*q)
      X2 <- Matrix::kronecker(Matrix::Matrix(t(Z), sparse = FALSE), Matrix::Diagonal(q))
      y2 <- as.numeric(Ymat)

      if (!is.null(halM)) {
        adjSig <- Matrix::kronecker(Matrix::Diagonal(T3), Matrix::Matrix(halM, sparse = FALSE))
        X2 <- adjSig %*% X2
        y2 <- as.numeric(adjSig %*% Matrix::Matrix(y2, ncol = 1))
      }

      exclude_idx <- NULL
      if (diagTF) {
        tmp <- matrix(seq_len(q * q), q, nrow = q, byrow = FALSE)
        exclude_idx <- diag(tmp)
      }

      pp <- adalasso.glmnet(
        X = X2, y = y2,
        nf = fold, alpha = 1,
        relaxTF = relaxTF,
        exclude = exclude_idx,
        standardize = standardize
      )

      A_lasso  <- matrix(pp$lasso,  nrow = q)
      A_Alasso <- matrix(pp$Alasso, nrow = q)

      Phi_lasso[, cols_i]  <- A_lasso
      Phi_Alasso[, cols_i] <- A_Alasso
    }

    diff <- sum((Phi0 - Phi_Alasso)^2)
    Phi0 <- Phi_Alasso
    iter <- iter + 1L
  }

  out <- list(
    model = "sPVAR", algo = "glmnet",
    Phi_hat_ols = Phi_ols,
    Phi_hat_lasso = Phi_lasso,
    Phi_hat_Alasso = Phi0,
    iter = iter - 1L,
    diff = diff,
    s = s, q = q, TT = TT, fold = fold, diagTF = diagTF
  )

  if (debiasTF || relaxedTF) {
    target_Phi <- if (debias_target == "Alasso") out$Phi_hat_Alasso else out$Phi_hat_lasso
    Phi_active <- sPVAR_active_refit(Yt, s, target_Phi,
                                     centerTF = TRUE,
                                     diagTF = diagTF,
                                     force_diag = force_diag,
                                     eps = eps_refit)
    out$Phi_hat_active <- Phi_active
    if (relaxedTF) {
      out$Phi_hat_relaxed <- gam * target_Phi + (1 - gam) * Phi_active
      out$gam <- gam
    }
  }

  out
}
