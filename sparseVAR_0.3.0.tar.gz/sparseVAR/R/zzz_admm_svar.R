# ------------------------------------------------------------
# Added in the ADMM extension for sparseVAR 0.2.0
# NOTE:
#   - Existing glmnet wrapper sVAR_adalasso() is left unchanged.
#   - ADMM follows the same objective scaling and output style as
#     the existing FISTA wrapper sVAR_adalasso_fista().
#   - KKT-based lambda grids are available for CV/theory selection.
# ------------------------------------------------------------

.parse_lambda_pair_admm <- function(lambda) {
  if (is.null(lambda)) return(list(lasso = NULL, adaptive = NULL))
  lam <- as.numeric(lambda)
  if (length(lam) == 1L) return(list(lasso = lam[1L], adaptive = lam[1L]))
  list(lasso = lam[1L], adaptive = lam[2L])
}

.theory_lambda_from_grid_admm <- function(lambdas, N, q) {
  if (length(lambdas) <= 1L) return(as.numeric(lambdas[1L]))
  target <- sqrt(log(q) / N)
  if (!is.finite(target) || target <= 0) target <- min(lambdas)
  lambdas[which.min(abs(log(pmax(lambdas, .Machine$double.eps)) - log(target)))]
}

.cv_select_lambda_admm <- function(X, Y, W, lambdas, SigmaInv,
                                   n_folds = 10,
                                   max_iter = 1000,
                                   rho = 1.0,
                                   tol = 1e-6) {
  X <- as.matrix(X); Y <- as.matrix(Y); W <- as.matrix(W)
  n <- nrow(X)
  folds <- rep(seq_len(n_folds), each = floor(n / n_folds) + 1L)[1L:n]
  SigArg <- if (is.null(SigmaInv)) matrix(0, 0, 0) else as.matrix(SigmaInv)

  cv <- numeric(length(lambdas))
  for (ii in seq_along(lambdas)) {
    lam <- lambdas[ii]
    sse <- 0
    for (ff in seq_len(n_folds)) {
      tr <- which(folds != ff)
      va <- which(folds == ff)

      fit <- admm_varp_multi_cpp(
        X = X[tr, , drop = FALSE],
        Y = Y[tr, , drop = FALSE],
        weights = W,
        lambda = lam,
        SigmaInv = SigArg,
        max_iter = as.integer(max_iter),
        rho = rho,
        tol = tol
      )

      Bhat <- fit$B
      Rv <- Y[va, , drop = FALSE] - X[va, , drop = FALSE] %*% Bhat
      if (is.null(SigmaInv)) {
        sse <- sse + sum(Rv^2)
      } else {
        sse <- sse + sum((Rv %*% SigmaInv) * Rv)
      }
    }
    cv[ii] <- sse
  }

  list(lambda = lambdas[which.min(cv)], cv = cv)
}

#' Sparse VAR(p) via ADMM (lasso and adaptive lasso)
#'
#' Estimates lasso and adaptive-lasso sparse VAR(p) coefficients using an
#' ADMM back-end with the same objective scaling used by
#' \code{\link{sVAR_adalasso_fista}}. The original glmnet-based
#' \code{\link{sVAR_adalasso}} is intentionally left unchanged.
#'
#' @param Yt Numeric matrix \eqn{k \times T}.
#' @param p Lag order.
#' @param fold Number of blocked CV folds for lambda selection.
#' @param diagTF Logical; unpenalize VAR self-lags.
#' @param standardize Logical; column-scale design/response before optimization (no centering).
#' @param updateSigma Logical; if \code{TRUE}, include \code{SigmaInv} in the quadratic loss.
#' @param sigma_diag_only Logical; if \code{TRUE}, use only diagonal covariance for \code{SigmaInv}.
#' @param lambda Optional scalar or length-two vector \code{c(lambda_lasso, lambda_adalasso)}.
#' @param lambda_seq Optional lambda grid to use when \code{lambda_rule != "fixed"}.
#' @param lambda_rule One of \code{"cv"}, \code{"theory"}, or \code{"fixed"}.
#' @param nlambda Size of lambda grid when \code{lambda_seq = NULL}.
#' @param lambda_min_ratio Ratio of minimum lambda to maximum lambda.
#' @param max_iter Maximum ADMM iterations.
#' @param rho ADMM augmentation parameter.
#' @param tol Convergence tolerance.
#' @param debiasTF Logical; if \code{TRUE}, compute active-set refit and relaxed estimate.
#' @param gam Mixing weight for relaxed estimate.
#' @param eps_w Stabilization constant for adaptive-lasso weights.
#'
#' @return A list in the same style as \code{sVAR_adalasso_fista()}, containing
#' \code{Phi_hat_lasso}, \code{Phi_hat_Alasso}, \code{Phi_hat_ols}, selected lambdas,
#' lambda grids, optional \code{SigmaInv}, and (if requested) debias/relaxed outputs.
#'
#' @export
sVAR_adalasso_admm <- function(Yt, p = 1,
                               fold = 5,
                               diagTF = TRUE,
                               standardize = TRUE,
                               updateSigma = FALSE,
                               sigma_diag_only = TRUE,
                               lambda = NULL,
                               lambda_seq = NULL,
                               lambda_rule = c("cv", "theory", "fixed"),
                               nlambda = 100,
                               lambda_min_ratio = 1e-4,
                               max_iter = 1000,
                               rho = 1.0,
                               tol = 1e-5,
                               debiasTF = FALSE,
                               gam = 0.5,
                               eps_w = 1e-8) {

  if (!is.matrix(Yt)) Yt <- as.matrix(Yt)
  k  <- nrow(Yt)
  TT <- ncol(Yt)
  if (p < 1L || p >= TT) stop("p must satisfy 1 <= p < ncol(Yt).")
  if (!exists("admm_varp_multi_cpp", mode = "function")) {
    stop("admm_varp_multi_cpp not found. Rebuild the package or run compileAttributes().")
  }

  lambda_rule <- match.arg(lambda_rule)
  lam_pair <- .parse_lambda_pair_admm(lambda)

  # center (no intercept), same convention as existing FISTA wrapper
  Yt <- Yt - rowMeans(Yt)

  des <- var_design(Yt, p = p)
  Xd <- as.matrix(des$X_design)  # n x d
  Y  <- as.matrix(des$Y_resp)    # n x k
  n  <- nrow(Xd)
  d  <- ncol(Xd)
  q  <- p * k^2

  # optional standardization (column-wise)
  X_sd <- rep(1, d); Y_sd <- rep(1, k)
  Xs <- Xd; Ys <- Y
  if (isTRUE(standardize)) {
    X_sd <- apply(Xd, 2, sd); X_sd[X_sd == 0] <- 1
    Y_sd <- apply(Y,  2, sd); Y_sd[Y_sd == 0] <- 1
    Xs <- scale(Xd, center = FALSE, scale = X_sd)
    Ys <- scale(Y,  center = FALSE, scale = Y_sd)
  }

  # SigmaInv (optional) from OLS residuals in standardized coordinates
  SigmaInv <- NULL
  if (isTRUE(updateSigma)) {
    B0 <- solve(crossprod(Xs) + diag(1e-8, d), crossprod(Xs, Ys))
    R0 <- Ys - Xs %*% B0
    Sig <- crossprod(R0) / nrow(R0)
    if (isTRUE(sigma_diag_only)) {
      SigmaInv <- diag(1 / pmax(diag(Sig), 1e-12), k, k)
    } else {
      sv <- svd(Sig); dd <- pmax(sv$d, 1e-12)
      SigmaInv <- sv$u %*% diag(1 / dd, k) %*% t(sv$u)
    }
  }

  # ----- Stage 1: lasso -----
  W0 <- .make_varp_weights(k, p, diagTF = diagTF)
  if (is.null(lam_pair$lasso)) {
    lambdas1 <- if (is.null(lambda_seq)) {
      .kkt_lambda_grid_fista(Xs, Ys, W0, SigmaInv, nlambda, lambda_min_ratio)
    } else {
      sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)
    }
    if (lambda_rule == "theory") {
      lam1 <- .theory_lambda_from_grid_admm(lambdas1, N = n, q = q)
      cv1 <- NULL
    } else {
      cv1 <- .cv_select_lambda_admm(Xs, Ys, W0, lambdas1, SigmaInv,
                                    n_folds = fold,
                                    max_iter = max_iter,
                                    rho = rho,
                                    tol = tol)
      lam1 <- cv1$lambda
    }
  } else {
    lambdas1 <- NULL
    cv1 <- NULL
    lam1 <- lam_pair$lasso
  }

  fit1 <- admm_varp_multi_cpp(
    X = Xs, Y = Ys, weights = W0, lambda = lam1,
    SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
    max_iter = as.integer(max_iter), rho = rho, tol = tol
  )
  B1 <- fit1$B

  # ----- Stage 2: adaptive lasso -----
  W1 <- 1 / pmax(abs(B1), eps_w)
  W1 <- pmin(W1, 1e6)
  if (diagTF) {
    for (ell in seq_len(p)) for (j in seq_len(k)) W1[(ell - 1L) * k + j, j] <- 0
  }

  if (is.null(lam_pair$adaptive)) {
    lambdas2 <- if (is.null(lambda_seq)) {
      .kkt_lambda_grid_fista(Xs, Ys, W1, SigmaInv, nlambda, lambda_min_ratio)
    } else {
      sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)
    }
    if (lambda_rule == "theory") {
      lam2 <- .theory_lambda_from_grid_admm(lambdas2, N = n, q = q)
      cv2 <- NULL
    } else {
      cv2 <- .cv_select_lambda_admm(Xs, Ys, W1, lambdas2, SigmaInv,
                                    n_folds = fold,
                                    max_iter = max_iter,
                                    rho = rho,
                                    tol = tol)
      lam2 <- cv2$lambda
    }
  } else {
    lambdas2 <- NULL
    cv2 <- NULL
    lam2 <- lam_pair$adaptive
  }

  fit2 <- admm_varp_multi_cpp(
    X = Xs, Y = Ys, weights = W1, lambda = lam2,
    SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else SigmaInv,
    max_iter = as.integer(max_iter), rho = rho, tol = tol
  )
  B2 <- fit2$B

  # Back-transform to original scale: Phi = t(B) with column scaling
  Phi_lasso  <- diag(Y_sd, k, k) %*% t(B1) %*% diag(1 / X_sd, d, d)
  Phi_Alasso <- diag(Y_sd, k, k) %*% t(B2) %*% diag(1 / X_sd, d, d)

  Phi_ols <- VAR_ols(Yt, p = p, eps = 1e-8)$Phi_hat

  out <- list(
    model = "sVAR", algo = "admm",
    Phi_hat_lasso  = Phi_lasso,
    Phi_hat_Alasso = Phi_Alasso,
    Phi_hat_ols    = Phi_ols,
    lambda_lasso   = lam1,
    lambda_adalasso = lam2,
    lambdas_lasso  = lambdas1,
    lambdas_adalasso = lambdas2,
    p = p, k = k, fold = fold, diagTF = diagTF,
    standardize = standardize,
    SigmaInv = SigmaInv,
    scales = list(X_sd = X_sd, Y_sd = Y_sd),
    rho = rho,
    converged_lasso = isTRUE(fit1$converged),
    converged_adalasso = isTRUE(fit2$converged),
    n_iter_lasso = fit1$n_iter,
    n_iter_adalasso = fit2$n_iter,
    cv_lasso = if (is.null(cv1)) NULL else cv1$cv,
    cv_adalasso = if (is.null(cv2)) NULL else cv2$cv
  )

  if (isTRUE(debiasTF)) {
    fa <- VAR_relaxed(Yt, Phi_Alasso, p = p, gam = gam)
    out$Phi_hat_active  <- fa$Phi_active
    out$Phi_hat_relaxed <- fa$Phi_relaxed
    out$gam <- gam
  }
  out
}

#' Alias for \code{\link{sVAR_adalasso_admm}}
#'
#' @inheritParams sVAR_adalasso_admm
#' @return See \code{\link{sVAR_adalasso_admm}}.
#' @export
admm_sVAR <- function(...) {
  sVAR_adalasso_admm(...)
}
